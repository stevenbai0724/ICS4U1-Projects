/*
 Steven Bai
Unit 2 Activity 3 - Assignment - Matching Game
Due date: Dec 11 2020 18:30
ICS4U1-D3

This programs simulates a matching game that works with arrays
A 4x4 grid of cards will be shown and the user choses 2 cards at a time, aiming to find all the pairs
The positions of the cards are randomized 


Fool proof features:
-User cannot choose the same button twice
-User cannot flip over more than 2 cards per turn
-User does not have to click "start" or "play" to begin
-User can use the clear button to reset 

To check whether or not the user has made a match, there are 2 pairs of variables "pos" and "card"
pos1 & pos2 stores the button number. If user clicks button 3 and then 12, pos1 = 3, pos2 = 12
card1 & card2 stores the card number (1 out of 8 cards). If user picks a star and then a flower, card1 = 7, card2 =2
 */

//required imports for arraylist and icons
import java.util.*;
import javax.swing.*;

public class matchingGame extends javax.swing.JFrame {

    static ArrayList<String> cards = new ArrayList(); //stores the cards that will be used in the game
    static ArrayList<String> set = new ArrayList(); //stores the original, unshuffled cards
    
    //importing the images from Source Packages > default package
    ImageIcon a = new javax.swing.ImageIcon(getClass().getResource("/1up.png"));
    ImageIcon b = new javax.swing.ImageIcon(getClass().getResource("/fire.png"));
    ImageIcon c = new javax.swing.ImageIcon(getClass().getResource("/ice.png"));
    ImageIcon d = new javax.swing.ImageIcon(getClass().getResource("/mini.png"));
    ImageIcon e = new javax.swing.ImageIcon(getClass().getResource("/mushroom.png"));
    ImageIcon f  = new javax.swing.ImageIcon(getClass().getResource("/penguin.png"));
    ImageIcon g = new javax.swing.ImageIcon(getClass().getResource("/propeller.png"));
    ImageIcon h = new javax.swing.ImageIcon(getClass().getResource("/star.png"));
    ImageIcon back = new javax.swing.ImageIcon(getClass().getResource("/card_back.png"));
    ImageIcon done = new javax.swing.ImageIcon(getClass().getResource("/done.png"));
    
    static int count = 0; //this is how many cards are currently selected, this will only be 0,1 or 2 (program will stop user from choosing 3_
    static String card1 = ""; //stores the first card, this will be one of the 8 cards from 0-7.
    static String card2 = ""; //stores the second card, cur 1 and 2 will reset after every 2 clicks from the user
    static int pos1 = 0;//stores the position of the first card, will be one of the buttons from 1-16
    static int pos2 = 0;//stores the position of the second card. Pos1 & 2 will reset every 2 clicks

    
    public matchingGame() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        btnClear = new javax.swing.JButton();
        btnGuess = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        btn6 = new javax.swing.JButton();
        btn8 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btn16 = new javax.swing.JButton();
        btn12 = new javax.swing.JButton();
        btn15 = new javax.swing.JButton();
        btn11 = new javax.swing.JButton();
        btn14 = new javax.swing.JButton();
        btn10 = new javax.swing.JButton();
        btn13 = new javax.swing.JButton();
        btn9 = new javax.swing.JButton();
        lblInstructions = new javax.swing.JLabel();
        btn1 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Verdana", 0, 36)); // NOI18N
        lblTitle.setText("Matching Game");

        btnClear.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnGuess.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnGuess.setText("Guess Again");
        btnGuess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuessActionPerformed(evt);
            }
        });

        btnExit.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        btn6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn6MouseClicked(evt);
            }
        });
        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });

        btn8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn8MouseClicked(evt);
            }
        });
        btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn8ActionPerformed(evt);
            }
        });

        btn5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn5MouseClicked(evt);
            }
        });
        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });

        btn3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn3MouseClicked(evt);
            }
        });
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });

        btn4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn4MouseClicked(evt);
            }
        });
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });

        btn7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn7MouseClicked(evt);
            }
        });
        btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn7ActionPerformed(evt);
            }
        });

        btn16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn16MouseClicked(evt);
            }
        });
        btn16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn16ActionPerformed(evt);
            }
        });

        btn12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn12MouseClicked(evt);
            }
        });
        btn12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn12ActionPerformed(evt);
            }
        });

        btn15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn15MouseClicked(evt);
            }
        });
        btn15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn15ActionPerformed(evt);
            }
        });

        btn11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn11MouseClicked(evt);
            }
        });
        btn11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn11ActionPerformed(evt);
            }
        });

        btn14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn14MouseClicked(evt);
            }
        });
        btn14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn14ActionPerformed(evt);
            }
        });

        btn10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn10MouseClicked(evt);
            }
        });
        btn10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn10ActionPerformed(evt);
            }
        });

        btn13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn13MouseClicked(evt);
            }
        });
        btn13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn13ActionPerformed(evt);
            }
        });

        btn9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn9MouseClicked(evt);
            }
        });
        btn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn9ActionPerformed(evt);
            }
        });

        lblInstructions.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblInstructions.setText("Click anywhere to start, clear when finished/stuck. Make sure to click Guess Again after each guess!");

        btn1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn1MouseClicked(evt);
            }
        });
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });

        btn2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/card_back.png"))); // NOI18N
        btn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn2MouseClicked(evt);
            }
        });
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblTitle)
                .addGap(275, 275, 275))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn5)
                                    .addComponent(btn1))
                                .addGap(53, 53, 53)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btn6)
                                            .addComponent(btn2))
                                        .addGap(49, 49, 49)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btn3)
                                            .addComponent(btn7))
                                        .addGap(47, 47, 47)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(btn4)
                                            .addComponent(btn8)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btn14)
                                            .addComponent(btn10))
                                        .addGap(49, 49, 49)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btn11)
                                            .addComponent(btn15))
                                        .addGap(47, 47, 47)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(btn12)
                                            .addComponent(btn16)))))
                            .addComponent(btn9)
                            .addComponent(btn13)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(175, 175, 175)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(86, 86, 86)
                        .addComponent(btnGuess, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(74, 74, 74)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(lblInstructions)))
                .addContainerGap(85, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn3)
                    .addComponent(btn4)
                    .addComponent(btn1)
                    .addComponent(btn2))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn5)
                    .addComponent(btn6)
                    .addComponent(btn7)
                    .addComponent(btn8))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btn9)
                        .addGap(42, 42, 42)
                        .addComponent(btn13))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn11)
                            .addComponent(btn12)
                            .addComponent(btn10))
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn14)
                            .addComponent(btn16)
                            .addComponent(btn15))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGuess, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(lblInstructions)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_btn6ActionPerformed

    private void btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn8ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn5ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn7ActionPerformed

    private void btn16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn16ActionPerformed

    private void btn12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn12ActionPerformed

    private void btn15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn15ActionPerformed

    private void btn11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn11ActionPerformed

    private void btn14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn14ActionPerformed

    private void btn10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn10ActionPerformed

    private void btn13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn13ActionPerformed

    private void btn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn9ActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // Exit button:
        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
 
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn1MouseClicked
        // First button
        //The button Mouse Clicked methods are pretty much all the same
        
        if(count==2 || pos1 == 1) return; //do not let user click same button, or if 2 buttons are already selected
        
        String temp = cards.get(0); //since this is the first button, get value of first number in cards
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){//compares the element from cards and sets image accordingly
            case("0"):
                btn1.setIcon(a);
                break;
            case("1"):
                btn1.setIcon(b);
                break;
            case("2"):
                btn1.setIcon(c);
                break;
            case("3"):
                btn1.setIcon(d);
                break;
            case("4"):
                btn1.setIcon(e);
                break;
            case("5"):
                btn1.setIcon(f);
                break;
            case("6"):
                btn1.setIcon(g);
                break;
            case("7"):
                btn1.setIcon(h);
                break;
        }    
        //execute if this is the first card
        if(count==0){
            count++; //update
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 1;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++; //update
            card2 = temp;
            pos2 = 1;
        }
        
    }//GEN-LAST:event_btn1MouseClicked
    private void btn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn2MouseClicked
        // Second button
        
        if(count==2||pos1 ==2) return; //don't let user click same button or more than 2 buttons
        String temp = cards.get(1); //second element of cards
        
         switch(temp){
            case("0"):
                btn2.setIcon(a);
                break;
            case("1"):
                btn2.setIcon(b);
                break;
            case("2"):
                btn2.setIcon(c);
                break;
            case("3"):
                btn2.setIcon(d);
                break;
            case("4"):
                btn2.setIcon(e);
                break;
            case("5"):
                btn2.setIcon(f);
                break;
            case("6"):
                btn2.setIcon(g);
                break;
            case("7"):
                btn2.setIcon(h);
                break;
        }
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 2;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 2;
        }
    }//GEN-LAST:event_btn2MouseClicked
    private void btn3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn3MouseClicked
        // third button
        if(count==2||pos1 ==3) return; //don't let user click same button or more than 2 buttons
        String temp = cards.get(2); //third element of cards
        
         switch(temp){
            case("0"):
                btn3.setIcon(a);
                break;
            case("1"):
                btn3.setIcon(b);
                break;
            case("2"):
                btn3.setIcon(c);
                break;
            case("3"):
                btn3.setIcon(d);
                break;
            case("4"):
                btn3.setIcon(e);
                break;
            case("5"):
                btn3.setIcon(f);
                break;
            case("6"):
                btn3.setIcon(g);
                break;
            case("7"):
                btn3.setIcon(h);
                break;
        }
        //first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 3;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 3;
        }
    }//GEN-LAST:event_btn3MouseClicked
    private void btn4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn4MouseClicked
        // Fourth button
        if(count==2||pos1 ==4) return; //don't let user click same button or more than 2 buttons
        String temp = cards.get(3); //fourth element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn4.setIcon(a);
                break;
            case("1"):
                btn4.setIcon(b);
                break;
            case("2"):
                btn4.setIcon(c);
                break;
            case("3"):
                btn4.setIcon(d);
                break;
            case("4"):
                btn4.setIcon(e);
                break;
            case("5"):
                btn4.setIcon(f);
                break;
            case("6"):
                btn4.setIcon(g);
                break;
            case("7"):
                btn4.setIcon(h);
                break;
        }//first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 4;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 4;
        }
    }//GEN-LAST:event_btn4MouseClicked
    private void btn5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn5MouseClicked
        // Fifth button
        if(count==2||pos1 ==5) return; //don't let user click same button or more than 2 buttons
        String temp = cards.get(4); //Fifth element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn5.setIcon(a);
                break;
            case("1"):
                btn5.setIcon(b);
                break;
            case("2"):
                btn5.setIcon(c);
                break;
            case("3"):
                btn5.setIcon(d);
                break;
            case("4"):
                btn5.setIcon(e);
                break;
            case("5"):
                btn5.setIcon(f);
                break;
            case("6"):
                btn5.setIcon(g);
                break;
            case("7"):
                btn5.setIcon(h);
                break;
        }//first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 5;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 5;
        }
    }//GEN-LAST:event_btn5MouseClicked
    private void btn6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn6MouseClicked
        // Sixth button
        if(count==2||pos1==6) return;//don't let user choose same button or more than 2 buttons
        String temp = cards.get(5); //sixth element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn6.setIcon(a);
                break;
            case("1"):
                btn6.setIcon(b);
                break;
            case("2"):
                btn6.setIcon(c);
                break;
            case("3"):
                btn6.setIcon(d);
                break;
            case("4"):
                btn6.setIcon(e);
                break;
            case("5"):
                btn6.setIcon(f);
                break;
            case("6"):
                btn6.setIcon(g);
                break;
            case("7"):
                btn6.setIcon(h);
                break;
        }
         //first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 6;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 6;
        }
    }//GEN-LAST:event_btn6MouseClicked
    private void btn7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn7MouseClicked
                // Seventh button
        if(count  ==2||pos1 ==7) return; //don't let user choose same button 
        String temp = cards.get(6); //Seventh element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn7.setIcon(a);
                break;
            case("1"):
                btn7.setIcon(b);
                break;
            case("2"):
                btn7.setIcon(c);
                break;
            case("3"):
                btn7.setIcon(d);
                break;
            case("4"):
                btn7.setIcon(e);
                break;
            case("5"):
                btn7.setIcon(f);
                break;
            case("6"):
                btn7.setIcon(g);
                break;
            case("7"):
                btn7.setIcon(h);
                break;
        }
         //first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 7;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 7;
        }
    }//GEN-LAST:event_btn7MouseClicked
    private void btn8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn8MouseClicked
                // Eighth button
        if(count==2||pos1 ==8)return; //don't let user choose the same button
        String temp = cards.get(7); //eighth element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn8.setIcon(a);
                break;
            case("1"):
                btn8.setIcon(b);
                break;
            case("2"):
                btn8.setIcon(c);
                break;
            case("3"):
                btn8.setIcon(d);
                break;
            case("4"):
                btn8.setIcon(e);
                break;
            case("5"):
                btn8.setIcon(f);
                break;
            case("6"):
                btn8.setIcon(g);
                break;
            case("7"):
                btn8.setIcon(h);
                break;
        }
         //first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 8;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 8;
        }
    }//GEN-LAST:event_btn8MouseClicked
    private void btn9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn9MouseClicked
                // Nineth button
        if(count==2||pos1==9)return; //don't let user choose the same button
        String temp = cards.get(8); //Nineth element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn9.setIcon(a);
                break;
            case("1"):
                btn9.setIcon(b);
                break;
            case("2"):
                btn9.setIcon(c);
                break;
            case("3"):
                btn9.setIcon(d);
                break;
            case("4"):
                btn9.setIcon(e);
                break;
            case("5"):
                btn9.setIcon(f);
                break;
            case("6"):
                btn9.setIcon(g);
                break;
            case("7"):
                btn9.setIcon(h);
                break;
        }
         //first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 9;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 9;
        }
    }//GEN-LAST:event_btn9MouseClicked
    private void btn10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn10MouseClicked
                // Tenth button
        if(count==2||pos1==10)return; //don't let user choose the same button
        String temp = cards.get(9); //Tenth element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn10.setIcon(a);
                break;
            case("1"):
                btn10.setIcon(b);
                break;
            case("2"):
                btn10.setIcon(c);
                break;
            case("3"):
                btn10.setIcon(d);
                break;
            case("4"):
                btn10.setIcon(e);
                break;
            case("5"):
                btn10.setIcon(f);
                break;
            case("6"):
                btn10.setIcon(g);
                break;
            case("7"):
                btn10.setIcon(h);
                break;
        }
         //first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 10;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 10;
        }
    }//GEN-LAST:event_btn10MouseClicked
    private void btn11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn11MouseClicked
                // 11th button
        if(count==2||pos1==11)return; //don't let user choose same button
        String temp = cards.get(10); //11th element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn11.setIcon(a);
                break;
            case("1"):
                btn11.setIcon(b);
                break;
            case("2"):
                btn11.setIcon(c);
                break;
            case("3"):
                btn11.setIcon(d);
                break;
            case("4"):
                btn11.setIcon(e);
                break;
            case("5"):
                btn11.setIcon(f);
                break;
            case("6"):
                btn11.setIcon(g);
                break;
            case("7"):
                btn11.setIcon(h);
                break;
        }//first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 11;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 11;
        }
    }//GEN-LAST:event_btn11MouseClicked
    private void btn12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn12MouseClicked
                // 12th button
        if(count==2||pos1==12)return; //don't let user choose same button
        String temp = cards.get(11); //12th element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn12.setIcon(a);
                break;
            case("1"):
                btn12.setIcon(b);
                break;
            case("2"):
                btn12.setIcon(c);
                break;
            case("3"):
                btn12.setIcon(d);
                break;
            case("4"):
                btn12.setIcon(e);
                break;
            case("5"):
                btn12.setIcon(f);
                break;
            case("6"):
                btn12.setIcon(g);
                break;
            case("7"):
                btn12.setIcon(h);
                break;
        }
         //first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 12;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 12;
        }
    }//GEN-LAST:event_btn12MouseClicked
    private void btn13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn13MouseClicked
                // 13th button
        if(count==2||pos1==13)return; //dont' let user choose same button
        String temp = cards.get(12); //13th element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn13.setIcon(a);
                break;
            case("1"):
                btn13.setIcon(b);
                break;
            case("2"):
                btn13.setIcon(c);
                break;
            case("3"):
                btn13.setIcon(d);
                break;
            case("4"):
                btn13.setIcon(e);
                break;
            case("5"):
                btn13.setIcon(f);
                break;
            case("6"):
                btn13.setIcon(g);
                break;
            case("7"):
                btn13.setIcon(h);
                break;
        }
         //first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 13;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 13;
        }
    }//GEN-LAST:event_btn13MouseClicked
    private void btn14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn14MouseClicked
                // 14th button
        if(count==2||pos1==14)return; //dont' let user choose same button        
        String temp = cards.get(13); //14th element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn14.setIcon(a);
                break;
            case("1"):
                btn14.setIcon(b);
                break;
            case("2"):
                btn14.setIcon(c);
                break;
            case("3"):
                btn14.setIcon(d);
                break;
            case("4"):
                btn14.setIcon(e);
                break;
            case("5"):
                btn14.setIcon(f);
                break;
            case("6"):
                btn14.setIcon(g);
                break;
            case("7"):
                btn14.setIcon(h);
                break;
        }//first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 14;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 14;
        }
    }//GEN-LAST:event_btn14MouseClicked
    private void btn15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn15MouseClicked
                // 15th button
        if(count==2||pos1==15)return; //dont' let user choose same button
        String temp = cards.get(14); //15th element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn15.setIcon(a);
                break;
            case("1"):
                btn15.setIcon(b);
                break;
            case("2"):
                btn15.setIcon(c);
                break;
            case("3"):
                btn15.setIcon(d);
                break;
            case("4"):
                btn15.setIcon(e);
                break;
            case("5"):
                btn15.setIcon(f);
                break;
            case("6"):
                btn15.setIcon(g);
                break;
            case("7"):
                btn15.setIcon(h);
                break;
        }//first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 15;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 15;
        }
    }//GEN-LAST:event_btn15MouseClicked
    private void btn16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn16MouseClicked
                // 16th button
        if(count==2||pos1==16)return; //dont' let user choose same button    
        String temp = cards.get(15); //16th element 
        
        //Switch case is used to set the icon to the corresponding image of the number in the cards ArrayList
         switch(temp){
            case("0"):
                btn16.setIcon(a);
                break;
            case("1"):
                btn16.setIcon(b);
                break;
            case("2"):
                btn16.setIcon(c);
                break;
            case("3"):
                btn16.setIcon(d);
                break;
            case("4"):
                btn16.setIcon(e);
                break;
            case("5"):
                btn16.setIcon(f);
                break;
            case("6"):
                btn16.setIcon(g);
                break;
            case("7"):
                btn16.setIcon(h);
                break;
        }//first card
        if(count==0){
            count++;
            card1 = temp; //set card to be the corresponding card of this button, which is declared above
            pos1 = 16;//set pos to be the corresponding button number
        }
        //second card
        else if(count==1){
            count++;
            card2 = temp;
            pos2 = 16;
        }
    }//GEN-LAST:event_btn16MouseClicked

    
    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // Clear button: erases everything and restarts the game, same code from main()
        
        //reset arrays
        set.clear();
        cards.clear();
        
        String temp = "";
        
        //by integer division, we can use this to fill set with 0 0 1 1 2 2 3 3 4 4 5 5 6 6 7 7 
        for(int i =0;i<16;i++){
             temp = Integer.toString(i/2); //integer division
             set.add(temp); //pushes back the current element into out set ArrayList
        }
        for(int i=0;i<=15;i++){
            int index = (int)(Math.random()*(16-i)); //after int conversion, generates random num from 0-16, then 0-15, then 0-14 etc 
            cards.add(set.get(index)); //chooses random index from set and adds it to cards
            set.remove(index); //removes index from set, since the element is now added to cards. 
            //note that .remove will erase the given index, not the element. e.g    remove(4) will remove the 5th element
        }
        
        //reset images too
        btn1.setIcon(back);
        btn2.setIcon(back);
        btn3.setIcon(back);
        btn4.setIcon(back);
        btn5.setIcon(back);
        btn6.setIcon(back);
        btn7.setIcon(back);
        btn8.setIcon(back);
        btn9.setIcon(back);
        btn10.setIcon(back);
        btn11.setIcon(back);
        btn12.setIcon(back);
        btn13.setIcon(back);
        btn14.setIcon(back);
        btn15.setIcon(back);
        btn16.setIcon(back);
        
        //reset variables
        pos1 = 0;
        pos2 = 0;
        card1 = "";
        card2 = "";
        count = 0;

    }//GEN-LAST:event_btnClearActionPerformed

    private void btnGuessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuessActionPerformed
        // Guess button: clicked when user needs to clear the 2 buttons they're selected
        //This is where the magic happens
        //From the user clicking the buttons, the program knows which ones were clicked and checks whether or not they match
        //the location of the buttons are stored in the pos1 and pos2 variables, the card type is in the card1 and card2
        //32 if statements are needed here to check which of the 16 buttons should be checked off as done or back
        
        //if user has selected 2 of the same cards, set the 2 corresponding buttons to the "done" image
        if(card1.equals(card2)){
            if(pos1==1 || pos2==1) btn1.setIcon(done); 
            if(pos1==2 || pos2==2) btn2.setIcon(done); 
            if(pos1==3 || pos2==3) btn3.setIcon(done); 
            if(pos1==4 || pos2==4) btn4.setIcon(done); 
            if(pos1==5 || pos2==5) btn5.setIcon(done); 
            if(pos1==6 || pos2==6) btn6.setIcon(done); 
            if(pos1==7 || pos2==7) btn7.setIcon(done); 
            if(pos1==8 || pos2==8) btn8.setIcon(done); 
            if(pos1==9 || pos2==9) btn9.setIcon(done); 
            if(pos1==10 || pos2==10) btn10.setIcon(done); 
            if(pos1==11 || pos2==11) btn11.setIcon(done); 
            if(pos1==12 || pos2==12) btn12.setIcon(done); 
            if(pos1==13 || pos2==13) btn13.setIcon(done); 
            if(pos1==14 || pos2==14) btn14.setIcon(done); 
            if(pos1==15 || pos2==15) btn15.setIcon(done);    
            if(pos1==16|| pos2==16) btn16.setIcon(done);
        }
        else {//if the user has not found a match, set the 2 buttons to "card back"
            if(pos1==1 || pos2==1) btn1.setIcon(back); 
            if(pos1==2 || pos2==2) btn2.setIcon(back); 
            if(pos1==3 || pos2==3) btn3.setIcon(back); 
            if(pos1==4 || pos2==4) btn4.setIcon(back); 
            if(pos1==5 || pos2==5) btn5.setIcon(back); 
            if(pos1==6 || pos2==6) btn6.setIcon(back); 
            if(pos1==7 || pos2==7) btn7.setIcon(back); 
            if(pos1==8 || pos2==8) btn8.setIcon(back); 
            if(pos1==9 || pos2==9) btn9.setIcon(back); 
            if(pos1==10 || pos2==10) btn10.setIcon(back); 
            if(pos1==11 || pos2==11) btn11.setIcon(back); 
            if(pos1==12 || pos2==12) btn12.setIcon(back); 
            if(pos1==13 || pos2==13) btn13.setIcon(back); 
            if(pos1==14 || pos2==14) btn14.setIcon(back); 
            if(pos1==15 || pos2==15) btn15.setIcon(back);    
            if(pos1==16 || pos2==16) btn16.setIcon(back);
        }

        //after checking, we need to clear the variables for the next pair
        pos1 = 0;
        pos2 = 0;
        card1 = "";
        card2 = "";
        count = 0;
    }//GEN-LAST:event_btnGuessActionPerformed
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(matchingGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(matchingGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(matchingGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(matchingGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new matchingGame().setVisible(true);
            }
        });
        
        
        /*the next block will set up the Arrays here in the main() method
        the user does not have to click "play" to start. Same code in btnClear(), which will reset everything
        */

        String temp = ""; //temporary variable 
        
        //by integer division, we can use this to fill set with 0 0 1 1 2 2 3 3 4 4 5 5 6 6 7 7 
        for(int i =0;i<16;i++){
             temp = Integer.toString(i/2); //integer division will get the pattern of 0 0 1 1 2 2 3 3.. etc.
             set.add(temp); //pushes back the current element into our set ArrayList
        }
        for(int i=0;i<=15;i++){
            int index = (int)(Math.random()*(16-i)); //after int conversion, generates random num from 0-16, then 0-15, then 0-14 etc 
            cards.add(set.get(index)); //chooses random index from set and adds it to cards
            set.remove(index); //removes index from set, since the element is now added to cards. 
            //**note that .remove will erase the given index, not the element. e.g remove(4) will remove the 5th element
        }
      
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn10;
    private javax.swing.JButton btn11;
    private javax.swing.JButton btn12;
    private javax.swing.JButton btn13;
    private javax.swing.JButton btn14;
    private javax.swing.JButton btn15;
    private javax.swing.JButton btn16;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn5;
    private javax.swing.JButton btn6;
    private javax.swing.JButton btn7;
    private javax.swing.JButton btn8;
    private javax.swing.JButton btn9;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnGuess;
    private javax.swing.JLabel lblInstructions;
    private javax.swing.JLabel lblTitle;
    // End of variables declaration//GEN-END:variables
}
