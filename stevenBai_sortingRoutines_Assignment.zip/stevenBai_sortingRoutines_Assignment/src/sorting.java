/*
Steven Bai
Unit 3 Activity 4 - Assignment - Sorting routines
Due date: Jan 28 2021 23:30
ICS4U1-D3

This program will generate random numbers and sort them with 4 of the following algorithms:
-bubble
-selection
-insertion
-quicksort

The functionality of the algorithms are briefly explained here:
bubble: swap 2 adjacent elements that are out of place until array is sorted
selection: goes through all elements of the array and finds the min/max, adding it to the beginning each time
insertion: orders the first 2 elements. Starting from the 3rd,  insert it to the correct position of the previous elements 
quicksort: a recursive sort that partitions the array from a pivot, and recursively sorts both sides of the pivot

The user can choose to sort in ascending or descending order.

 */
public class sorting extends javax.swing.JFrame {
    
   
    
    public sorting() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        lblTitle1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnBubble = new javax.swing.JRadioButton();
        btnInsertion = new javax.swing.JRadioButton();
        btnQuicksort = new javax.swing.JRadioButton();
        btnSelection = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        inc = new javax.swing.JRadioButton();
        dec = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        txtInput = new javax.swing.JTextField();
        btnSort = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaSort = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaUnsort = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle1.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
        lblTitle1.setText("Sorting Routines");

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel3.setText("Sorting Algorithm: ");

        buttonGroup1.add(btnBubble);
        btnBubble.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnBubble.setText("Bubble ");

        buttonGroup1.add(btnInsertion);
        btnInsertion.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnInsertion.setText("Insertion ");

        buttonGroup1.add(btnQuicksort);
        btnQuicksort.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnQuicksort.setText("Quicksort");
        btnQuicksort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuicksortActionPerformed(evt);
            }
        });

        buttonGroup1.add(btnSelection);
        btnSelection.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSelection.setText("Selection");

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel4.setText("Order: ");

        buttonGroup2.add(inc);
        inc.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        inc.setText("Increasing");
        inc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                incActionPerformed(evt);
            }
        });

        buttonGroup2.add(dec);
        dec.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        dec.setText("Decreasing");

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel5.setText("Amount of numbers to sort:");

        txtInput.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N

        btnSort.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSort.setText("Sort ");
        btnSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSortActionPerformed(evt);
            }
        });

        areaSort.setColumns(20);
        areaSort.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        areaSort.setRows(5);
        jScrollPane1.setViewportView(areaSort);

        areaUnsort.setColumns(20);
        areaUnsort.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        areaUnsort.setRows(5);
        jScrollPane2.setViewportView(areaUnsort);

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel6.setText("Sorted");

        jLabel7.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel7.setText("Unsorted");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(217, 217, 217)
                        .addComponent(lblTitle1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSelection)
                                    .addComponent(btnInsertion)
                                    .addComponent(btnQuicksort))
                                .addGap(167, 167, 167))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnBubble)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4)
                                .addGap(21, 21, 21)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dec)
                            .addComponent(inc)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addComponent(btnSort)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(140, 140, 140))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle1)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBubble)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(inc))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSelection)
                    .addComponent(dec))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnInsertion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnQuicksort)
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSort))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 239, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnQuicksortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuicksortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnQuicksortActionPerformed

    private void btnSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSortActionPerformed
        //Sort button 
        int n = Integer.parseInt(txtInput.getText()); //get size of array, as well as the number of random numbers to generate
        int[] arr = new int[n];
        int[] newArr = new int[1]; //the new sorted array that will be obtained from the sorting methods
        areaUnsort.setText("");//clear text
        areaSort.setText("");
        
        for(int i=0;i<n;i++){
            //populating arr with random numbers, [-1000,1000]
            int x = (int)(Math.random()*(2001))-1000; // range -1000 ->1000
            arr[i] = x;
            areaUnsort.append(String.valueOf(x) + '\n'); //add unsorted element to textarea
        }
        //determine order and algorithm to use
        Boolean ascend = inc.isSelected(); //decides which order to sort
        
        //all sort methods will take arr, size and order. They will return the sorted array
        //based on the radio button group, choose which sorting method to use
        if(btnBubble.isSelected()){
              newArr = bubble(arr,n, ascend); 
        }
        else if(btnSelection.isSelected()){
              newArr = selection(arr, n, ascend);
        }
        else if(btnInsertion.isSelected()){
              newArr = insertion(arr, n, ascend);
        }
        else{
              newArr = quicksort(arr, 0, n-1, ascend);
        }
        //append the sorted array to the new text area
        for(int i=0;i<n;i++){
            areaSort.append(String.valueOf(newArr[i]) + '\n');
        }
        
        
    }//GEN-LAST:event_btnSortActionPerformed

    private void incActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_incActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_incActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(sorting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(sorting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(sorting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(sorting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new sorting().setVisible(true);
            }
        });
    }
    public int[] bubble(int arr[], int n, Boolean asc){ //bubble sort, returns the sorted array
       

            while(true){
                Boolean sorted = true;
                
                for(int i=0;i<n-1;i++){
                    //the magic happens here
                    //If we want the ascending array, we swap when arr[i]>arr[i+1]
                    //If we want the descending array, we swap when arr[i]<arr[i+1]
                    if((arr[i]>arr[i+1] && asc) || (arr[i]<arr[i+1] && !asc) ){
                        sorted =false; //not sorted if we find out of place elements
                        //swap
                        int temp = arr[i];
                        arr[i] = arr[i+1];
                        arr[i+1] = temp;
                        
                    }
                }
                if(sorted)break; //break if we do not find any out of place elements
            }
        

        return arr; //return sorted array
    }
    public int[] selection(int []arr, int n, Boolean asc){ //selection sort, returns int[]
        
        
        for(int i=0;i<n-1;i++){
            int mn = 1000000; //needed for ascending array
            int mx = -1000000; //needed for descending array
            int indexMx = 0; //index for swap
            int indexMn = 0;
            //find max and min in the array , store the indicies for swap
            for(int j=i;j<n;j++){
                if(arr[j]<mn){
                    mn = arr[j];
                    indexMn = j;
                }
                if(arr[j]>mx){
                    mx = arr[j];
                    indexMx = j;
                }
            }
            //we have found the max and min in the array, so we will use these values accordingly for a swap
            //swap beginning with max for descending, min for ascending
            if(asc){
                int temp = arr[i];
                arr[i] = arr[indexMn];
                arr[indexMn] = temp;
            }else{
                int temp = arr[i];
                arr[i] = arr[indexMx];
                arr[indexMx] = temp;
            }
            
        }
        return arr;
    }
    public int[] insertion (int []arr, int n, Boolean asc){
        //with insertion sort, we take an element i and keep swapping with i-1, i-2 .... until we find the right spot or when we reach i=0
        //we can assume that for any i>1, all elements from 1 to i-1 are sorted, we just to find where to insert element i, hence the name
        for(int i=1;i<n;i++){
            int temp = arr[i];
            int j = i-1; //index before
            
            while(j>=0){ //shift until we reach beginning of array
                //we must consider these 2 conditions, for ascending and descending respectively
                if(asc && arr[j]<temp)break;
                if(!asc && arr[j]>temp)break;
                arr[j+1] = arr[j]; //shift
                j--;
            }
            arr[j+1] = temp; //insert arr[i] into the correct pos.
        }
        
        return arr;
    }
    public int[] quicksort(int[] arr, int lo, int hi, Boolean asc){
            int i = lo;
            int j = hi;
            int temp;
            int p =arr[(i+j)/2]; //pivot
            
            while(i<=j){
                if(asc){
                    //find two elements to swap for asc
                    while(arr[i]<p)i++;
                    while(arr[j]>p)j--;
                }
                else{//find swap, for !asc
                    while(arr[i]>p)i++;
                    while(arr[j]<p)j--;
                }
                if(i<=j){//swap into correct positions;
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                    i++;
                    j--;
                    
                }
            }
            if(lo<j){//recursively sort lower subarray
                quicksort(arr, lo, j, asc);
            }
            if(i<hi){//recursively sort upper subarray
                quicksort(arr, i, hi, asc);
            }
            return arr;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaSort;
    private javax.swing.JTextArea areaUnsort;
    private javax.swing.JRadioButton btnBubble;
    private javax.swing.JRadioButton btnInsertion;
    private javax.swing.JRadioButton btnQuicksort;
    private javax.swing.JRadioButton btnSelection;
    private javax.swing.JButton btnSort;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JRadioButton dec;
    private javax.swing.JRadioButton inc;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblTitle1;
    private javax.swing.JTextField txtInput;
    // End of variables declaration//GEN-END:variables
}
