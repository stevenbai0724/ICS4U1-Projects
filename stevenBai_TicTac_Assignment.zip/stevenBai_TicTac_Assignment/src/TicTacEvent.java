/*
 Steven Bai
Unit 2 Activity 5 - Assignment - Tic Tac Toe
Due date: Dec 18 2020 23:00
ICS4U1-D3


This program will use arrays to create a tic tac toe game
The user takes turns and clicks the buttons, 'X's and 'O's will alternate
When either X or O creates a line or a diagonal of 3 in a row, they will have won

This is the object that implements actionlisteners and performs the calculations for the game
The event file will keep track of victories, clicks and checking for wins

 */
//imports 
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class TicTacEvent implements ItemListener, ActionListener, Runnable {
    ticTac gui; // we can use gui.boxes[][] etc. to access the original class' variables
    ImageIcon a = new javax.swing.ImageIcon(getClass().getResource("/X.png")); //image
    ImageIcon b = new javax.swing.ImageIcon(getClass().getResource("/O.png")); //image
    ImageIcon back = new javax.swing.ImageIcon(getClass().getResource("/card_back.png")); //image

    int clicks = 0; //click counter
    int win = 0;  //win condition
     //counters for wins, tie will count as win for both
    int xCount = 0;
    int oCount = 0;
    int[][] check = new int[3][3];//array to check for wins

    
    public TicTacEvent (ticTac in){
        gui = in;
        //initialize the check array
        for (int row=0; row<=2; row++){
           for (int col=0; col<=2; col++){
               check[row][col]=0;
           }
       }
    }
    
    //this part will run when an ActionEvent in the ticTac class is triggered
    //This method will get the command and act corresponding by the if statements
    public void actionPerformed (ActionEvent event) {
       String command = event.getActionCommand();   
       
       if (command.equals("Play")) {
           reset();
       }
       if (command.equals("1")) {
           b1();
       }
       if (command.equals("2")) {
           b2();
       }
       if (command.equals("3")) {
           b3();
       }
       if (command.equals("4")) {
           b4();
       }
       if (command.equals("5")) {
           b5();
       }
       if (command.equals("6")) {
           b6();
       }
       if (command.equals("7")) {
           b7();
       }
       if (command.equals("8")) {
           b8();
       }
       if (command.equals("9")) {
           b9();
       }
       
    }
   
//these 9 methods are the same so I will comment on the first one
public void b1() {
        clicks ++; //keeps track of counting to see which image to update. Odd for Xs, even for Os
        //X
        if ((clicks%2)==1){
            gui.boxes[0][0].setIcon(a); //set image
            check[0][0] = 1; //update win check array
        } 
        //O
        else {
            gui.boxes[0][0].setIcon(b); //set image
            check[0][0] = 2; //update win check array
        }
        winner(); //check for a win after clicking button
    } 
public void b2() {
    clicks = clicks + 1;
    if ((clicks%2)==1){
        gui.boxes[0][1].setIcon(a);
        check[0][1] = 1;
    } else {
        gui.boxes[0][1].setIcon(b);
        check[0][1] = 2;
    }
    winner();
}
public void b3() {
        clicks = clicks + 1;
            if ((clicks%2)==1){
            gui.boxes[0][2].setIcon(a);
            check[0][2] = 1;
        } else {
            gui.boxes[0][2].setIcon(b);
            check[0][2] = 2;
        }
        winner();
}
public void b4() {
    clicks = clicks + 1;
    if ((clicks%2)==1){
        gui.boxes[1][0].setIcon(a);
        check[1][0] = 1;
    } else {
        gui.boxes[1][0].setIcon(b);
        check[1][0] = 2;
    }
    winner();
}
 public void b5() {
    clicks = clicks + 1;
    if ((clicks%2)==1){
        gui.boxes[1][1].setIcon(a);
        check[1][1] = 1;
    } else {
        gui.boxes[1][1].setIcon(b);
        check[1][1] = 2;
    }
    winner();
 }
 public void b6() {
    clicks = clicks + 1;
    if ((clicks%2)==1){
        gui.boxes[1][2].setIcon(a);
        check[1][2] = 1;
    } else {
        gui.boxes[1][2].setIcon(b);
        check[1][2] = 2;
    }
    winner();
 }
public void b7() {
    clicks = clicks + 1;
    if ((clicks%2)==1){
        gui.boxes[2][0].setIcon(a);
        check[2][0] = 1;
    } else {
        gui.boxes[2][0].setIcon(b);
        check[2][0] = 2;
    }
    winner();
 }
 public void b8() {
    clicks = clicks + 1;
    if ((clicks%2)==1){
        gui.boxes[2][1].setIcon(a);
        check[2][1] = 1;
    } else {
        gui.boxes[2][1].setIcon(b);
        check[2][1] = 2;
    }
    winner();
 }
public void b9() {
    clicks = clicks + 1;
    if ((clicks%2)==1){
        gui.boxes[2][2].setIcon(a);
        check[2][2] = 1;
    } else {
        gui.boxes[2][2].setIcon(b);
        check[2][2] = 2;
    }
    winner();
    }

void reset() {
        //Following code restart the game
        
        for(int i =0;i<=2;i++){
             for(int j=0;j<=2;j++){
                 gui.boxes[i][j].setIcon(back); //set default image
                 gui.boxes[i][j].setEnabled(true); //enable the buttons
                 check[i][j]=0; //clear check array
                 clicks = 0; //reset clicks
                 win  =0; //reset win

             }
            
        }
  
}

void winner() {
 for (int x=0; x<=2; x++){//checking each of the rows
            if ((check[x][0]==check[x][1])&&(check[x][0]==check[x][2])) { 
                if (check[x][0]==1) {//1 corresponds to X
                    JOptionPane.showMessageDialog(null, "X is the winner");//pop up message
                    win = 1;
                    xCount++;
                    gui.blank1.setText("X Wins: " + xCount);
                } else if (check[x] [0]==2){//2 corresponds to O
                    JOptionPane.showMessageDialog(null, "O is the winner");//pop up message
                    win = 1;
                    oCount++;
                    gui.blank2.setText("O wins: " + oCount); 
                }
        }
}
  for (int x=0; x<=2; x++){//check each column
            if ((check[0][x]==check[1][x])&&(check[0][x]==check[2][x])) {
                if (check[0][x]==1) {//1 corresponds to X
                    JOptionPane.showMessageDialog(null, "X is the winner");//pop up message
                    win = 1;
                    xCount++;
                    gui.blank1.setText("X Wins: " + xCount);
            
                } else if (check[0][x]==2) {//2 corresponds to O
                    JOptionPane.showMessageDialog(null, "O is the winner");//pop up message
                    win = 1;
                    oCount++;
                    gui.blank2.setText("O wins: " + oCount);
                }
            }
   }
   //check both diagonals for winner
   if (((check[0][0]==check[1][1])&&(check[0][0]==check[2][2]))|| ((check[2][0]==check[1][1])&&(check[1][1]==check[0][2]))){
            if (check[1][1]==1) {//check middle button to see which message to display
                JOptionPane.showMessageDialog(null, "X is the winner");//pop up message
                win = 1;
                xCount++;
                gui.blank1.setText("X Wins: " + xCount);
                
            } else if (check[1][1]==2) {
                JOptionPane.showMessageDialog(null, "O is the winner");//pop up message
                win = 1;
                oCount++;
                gui.blank2.setText("O wins: " + oCount); 
            }
  }
   //a tie will occur when all buttons are clicked and no winner is found
   //give victory to both sides
  if ((clicks==9) && (win==0)) {
            JOptionPane.showMessageDialog(null, "The game is a tie");
            xCount++;
            oCount++;
            gui.blank1.setText("X Wins: " + xCount);
            gui.blank2.setText("O wins: " + oCount);
  }
  //when all buttons are clicked or when victory is found, disable buttons
  if(clicks==9 || win==1){
      for(int i =0;i<=2;i++){
          for(int j=0;j<=2;j++){
              gui.boxes[i][j].setEnabled(false);//disable
          }
      }
  }
  

}
    //these methods are needed to prevent errors
    public void itemStateChanged(ItemEvent e) {
     throw new UnsupportedOperationException("Not supported yet.");
     }
     public void run() {
     throw new UnsupportedOperationException("Not supported yet.");
     }

}