/*
 Steven Bai
Unit 2 Activity 5 - Assignment - Tic Tac Toe
Due date: Dec 18 2020 23:00
ICS4U1-D3


This program will use arrays to create a tic tac toe game
The user takes turns and clicks the buttons, 'X's and 'O's will alternate
When either X or O creates a line or a diagonal of 3 in a row, they will have won
There is a counter that increments the wins for X and O, ties will count as victory for both
The play button will reset the game (not the counters)

 */
//required imports for drawing classes
import java.awt.*;
import javax.swing.*;

public class ticTac extends javax.swing.JFrame {
     TicTacEvent tictac = new TicTacEvent(this); //event object
    
    //required stuff for making the board
     JPanel row1 = new JPanel(); //outline box
     JButton[ ] [ ] boxes = new JButton [3][3]; //array of 9 JButtons
     JButton play = new JButton ("Play"); //play button
     
     //These 2 boxes will display score
     JTextField blank1 = new JTextField();
     JTextField blank2 = new JTextField();
     
     ImageIcon back = new javax.swing.ImageIcon(getClass().getResource("/card_back.png")); //image


    public ticTac() { //method that creates board
        super ("GUI a la tic toc"); //program name
        setSize (500,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        FlowLayout layout = new FlowLayout(); //flow layout adjusts the arrangement of buttons to make them centered
        setLayout(layout);
        int name = 0; //the name of the current button (1-9)
        String newname;
        GridLayout layout1 = new GridLayout(4, 3);//arranges everything in a 4x3 grid and makes them equal size
        row1.setLayout(layout1); //row1 will be added to the GridLayout

        //creating the buttons in the JButton array boxes[3][3]
        //top 3 rows of gridLayout
        for (int x=0; x<=2; x++){
            for (int y=0; y<=2; y++){
                name = name + 1; //increment current name
                newname = Integer.toString(name); 
                boxes[x][y] = new JButton(newname); //set name
                boxes[x][y].setIcon(back); //set image
                row1.add(boxes[x][y]); //add the current JButton to the gridLayout
            }
        }
        //bottom row of gridLayout
        row1.add(blank1); //score for X
        row1.add(play); //play button
        row1.add(blank2); //score for O
        
        //setting fonts and sizes
        play.setFont(new Font("Arial", Font.PLAIN, 28));
        blank1.setText("X wins: " + tictac.xCount);  blank1.setFont(new Font("Arial", Font.PLAIN, 28));
        blank2.setText("O wins: " + tictac.oCount);  blank2.setFont(new Font("Arial", Font.PLAIN, 28));
        //do not let user edit the score
        blank1.setEditable(false);
        blank2.setEditable(false);
        add (row1);
        //add action listeners for the buttons to respond on mouse clicks
        play.addActionListener(tictac);
        for (int x=0; x<=2; x++){
            for (int y=0; y<=2; y++){
                boxes[x][y].addActionListener(tictac);
            }
        }

        setVisible(true); //show on screen
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 564, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 536, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ticTac.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ticTac.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ticTac.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ticTac.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        new ticTac(); //initialize program
       
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
