/*
Steven Bai
Activity 6 - Assignment - Math Class
Due date: Dec 3 2020 11:59 pm
ICS4U1-D3
this program is a console that uses Math. methods that the user can interact with
the code is implemented in a procedural manner with manually coded methods to show how they work
*/

//we can use the 2 imports with a * to get everything we need, including scanners, math, etc
import java.util.*;
import java.io.*;

class mathClass{

    //messages the the program will use, they are printed in the message() method to save time
    static String welcome1 = "-------------------------------------------------------------------------------------";
    static String welcome2 = "Welcome to Steven Bai's math class. Please type in a choice from 1-5:";
    static String operation1 = "1 - Random Number";
    static String operation2 = "2 - Exponents";
    static String operation3 = "3 - Rounding";
    static String operation4 = "4 - Maximum";
    static String operation5 = "5 - Minimum";
    static String leave = "Enter any other key to quit";

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in); 

        message();//prints the main menu and makes the main method look less cluttered
        String choice = sc.nextLine();

        if(choice.equals("1")){
            System.out.println("Enter the lower and upper range for a random number generator");
            System.out.print("Lower: "); int l = sc.nextInt();
            System.out.print("Upper: "); int u = sc.nextInt(); 
            System.out.println(random(l,u));
                
        }
        else if(choice.equals("2")){
            System.out.println("Enter the base and the exponent to be evaluated:");
            System.out.print("Base: "); int b = sc.nextInt();
            System.out.print("Exponent: "); int e = sc.nextInt();
            System.out.println(exponents(b,e));
                
        }
        else if(choice.equals("3")){
            System.out.print("Enter a number to be rounded: ");
            double d = sc.nextDouble();
            System.out.println(rounding(d));
        }
        else if(choice.equals("4")){
            System.out.println("Enter 2 numbers to find the maximum:");
            System.out.print("1st: "); int b = sc.nextInt();
            System.out.print("2nd: "); int e = sc.nextInt();
            System.out.println(maximum(b,e));
                
        }
        else if(choice.equals("5")){
            System.out.println("Enter 2 numbers to find the minimum:");
            System.out.print("1st: "); int b = sc.nextInt();
            System.out.print("2nd: "); int e = sc.nextInt();
            System.out.println(minimum(b,e));
                
        }
    }

    //returns a random integer from the lower range to the upper range that the user inputs
    public static int random(int lower ,int upper){
        return (int)(Math.random()*(upper-lower+1))+lower;
    }
    //returns the evaluated exponent that the user inputs
    public static int exponents(int base, int exp){
        return (int)(Math.pow(base, exp));
    }
    //returns the nearest integer from the double that user has entered
    public static int rounding(double x){
        return (int)(Math.round(x));
    }
    //returns max of 2 numbers
    public static int maximum(int a, int b){
        return Math.max(a,b);
    }
    //returns min of numbers
    public static int minimum(int a, int b){
        return Math.min(a, b);
    }
    public static void message(){ //this will print the main menu every time message() is called to save typing
        System.out.println(welcome1);
        System.out.println(welcome2);
        System.out.println(operation1);
        System.out.println(operation2);
        System.out.println(operation3);
        System.out.println(operation4);
        System.out.println(operation5);
        System.out.println(leave);
    }
}
