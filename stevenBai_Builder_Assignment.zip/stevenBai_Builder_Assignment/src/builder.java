/*
Steven Bai
Unit 2 Activity 5.5 - Assignment - Builder 
Due date: Jan 07 2021 23:30
ICS4U1-D3

This program will implement reading/writing files into a GUI which the user can use to manipulate text files
The program has the following operations:

2 boxes for the user to enter in a specific file loaction
Open: displays contents of selected .txt file loaction
Save: rewrites contents of opened file with the contents on screen (first input box)
Save as: rewrites contents of a different file with the contents on screen (second input box)
Reset: Clears text and resets buttons
Append: Add the text on screen to another file, without replacing anything

Note that for users other than myself, the direct file location is required for the program to work. 
i.e you must type in the path location, such as C:\\Users\\Mike\\Desktop\\test.txt
*/

import java.io.*; //required for all the filewriters/readers we will be using
import java.util.*; //required for ArrayLists
public class builder extends javax.swing.JFrame {

    public boolean SaveAs = false; //false means the save as is not toggled, otherwise true
    public String filename,newfilename,fillerString; //declaring strings, used to output
    public ArrayList<String> LoadedArray = new ArrayList(); //arraylist used in the open method, stores each line of a text file
    BufferedReader fileIn; //reader is required to read files
    
    
    
    public builder() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        txtFileChooser = new javax.swing.JTextField();
        lblFileChooser = new javax.swing.JLabel();
        lblNewFileName = new javax.swing.JLabel();
        txtNewFileName = new javax.swing.JTextField();
        btnSave = new javax.swing.JButton();
        btnAppend = new javax.swing.JButton();
        btnSaveAs = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        btnOpen = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaDisplay = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Verdana", 0, 36)); // NOI18N
        lblTitle.setText("Builder Utility ");

        txtFileChooser.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtFileChooser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFileChooserActionPerformed(evt);
            }
        });

        lblFileChooser.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblFileChooser.setText("Enter a file name:");

        lblNewFileName.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblNewFileName.setText("Enter a new file name:");

        txtNewFileName.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtNewFileName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNewFileNameActionPerformed(evt);
            }
        });

        btnSave.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btnAppend.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnAppend.setText("Append");
        btnAppend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAppendActionPerformed(evt);
            }
        });

        btnSaveAs.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSaveAs.setText("Save As");
        btnSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveAsActionPerformed(evt);
            }
        });

        btnReset.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        btnOpen.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnOpen.setText("Open");
        btnOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOpenActionPerformed(evt);
            }
        });

        areaDisplay.setColumns(20);
        areaDisplay.setRows(5);
        jScrollPane1.setViewportView(areaDisplay);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setText("Testing box (used to hold file locations for testing) :\nC:\\Users\\steve\\Desktop\\Steven\\School\\Gr 11\\ICS\\test.txt\nC:\\Users\\steve\\Desktop\\Steven\\School\\Gr 11\\ICS\\test2.txt");
        jScrollPane2.setViewportView(jTextArea1);

        lblNewFileName.setEnabled(false);
        txtNewFileName.setEnabled(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblFileChooser)
                                .addGap(38, 38, 38)
                                .addComponent(txtFileChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblNewFileName)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtNewFileName, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSave)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnOpen)
                                .addGap(18, 18, 18)
                                .addComponent(btnReset))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnAppend)
                                .addGap(18, 18, 18)
                                .addComponent(btnSaveAs))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 569, Short.MAX_VALUE)
                            .addComponent(jScrollPane2))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFileChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFileChooser)
                    .addComponent(btnSave)
                    .addComponent(btnReset)
                    .addComponent(btnOpen))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNewFileName)
                    .addComponent(txtNewFileName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAppend)
                    .addComponent(btnSaveAs))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(69, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtFileChooserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFileChooserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFileChooserActionPerformed

    private void txtNewFileNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNewFileNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNewFileNameActionPerformed

    private void btnOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOpenActionPerformed
        // Opens text file from input
        filename = txtFileChooser.getText();
        LoadedArray.clear();//remove existing elements
        areaDisplay.setText(""); //clear text
        String word = "";
        String ans = "";

        try{
            //open the direct file location , e.g C:\\Users\\Mike\\Desktop\\test.txt
            fileIn = new BufferedReader(new FileReader(filename));
        }
        catch(Exception e){
            System.out.println("not found");
        }
        try{ //read each line of file and add it to the LoadedArray
            while((word = fileIn.readLine()) != null) {
           LoadedArray.add(word);
          }
        }
        catch (IOException ex){
        }
        //append contents of loadedArray to string ans
        for(int i=0;i<LoadedArray.size();i++){
            ans+= (LoadedArray.get(i)) + "\n";
        }
         //update on screen text 
         areaDisplay.setText(ans);
        
        
    }//GEN-LAST:event_btnOpenActionPerformed

    private void btnSaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveAsActionPerformed
        // SaveAs will take on-screen text and save it to another existing file, replacing its original contents 
        // User is expected to enter the location of the new file to be saved to 
       
        //Toggle the save as. Now, the user can only type in the second box and the "Save" button will perform this action and return the save as to untoggled again
        SaveAs = true;
       //disabled original fields 
       txtFileChooser.setEnabled(false);
       lblFileChooser.setEnabled(false);
       
        //enable new field for user to enter new save location
        txtNewFileName.setEnabled(true);
        lblNewFileName.setEnabled(true);

        
    }//GEN-LAST:event_btnSaveAsActionPerformed

    private void btnAppendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAppendActionPerformed
        // Appends the text on-screen to the selected file in txtFileChooser
        filename = txtFileChooser.getText(); //user selected file to append to 
        /*To append, we can use a Java FileWriter, also imported from java.io 
            The FileWriter will select the location, and BufferedWriting will do the appending
            We will also need a PrintWriter for the text to show up
            Note that a PrintWriter itself will only replace the text in a file(As done in the Save button). FileWriter and BufferedWriter will do the appending
        */
        try(FileWriter fw = new FileWriter(filename, true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw))
        {
        out.println(areaDisplay.getText());
        
        } catch (IOException e) {
        
        }
        areaDisplay.setText("");//clear screen when done appending
    }//GEN-LAST:event_btnAppendActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        //Clears all text and variables
        SaveAs = false;
        areaDisplay.setText("");
        txtNewFileName.setText("");
        txtFileChooser.setText("");
        
        //set "save as" field to its default
        this.txtNewFileName.setEnabled(false);
        this.lblNewFileName.setEnabled(false);
        //set the reglular field to its default
        this.lblFileChooser.setEnabled(true);
        this.txtFileChooser.setEnabled(true);
    }//GEN-LAST:event_btnResetActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        // replaces selected file with contents on the screen
        // printwriter will rewrite the selected file
        if(SaveAs){//run this if user chooses to save to another file location
            newfilename = txtNewFileName.getText(); //get location of new file
            PrintWriter pw = null;
            try { // try is used to enable the catching of exceptions
            pw = new PrintWriter(new FileOutputStream(newfilename));
             } catch (FileNotFoundException e) {
            e.printStackTrace();
         }
         //store the text on screen 
         fillerString = areaDisplay.getText();
         //note that user can choose to set a file to "". This is useful if they would like to clear a text file
         
         //rewrite the file
         pw.println(fillerString);
         pw.close();
         
         
         //Return the 2 fields to its original state
         txtNewFileName.setText("");
         this.txtNewFileName.setEnabled(false);
         this.lblNewFileName.setEnabled(false);
         txtFileChooser.setText("");
         this.lblFileChooser.setEnabled(true);
         this.txtFileChooser.setEnabled(true);
         SaveAs = false;
         
         
        }
        else{//Same as above, except we will save to file in the first box
            newfilename = txtFileChooser.getText();
            PrintWriter pw = null;
            try{
                    pw = new PrintWriter(new FileOutputStream(newfilename));
            }catch(FileNotFoundException e){e.printStackTrace();}
            
            fillerString = areaDisplay.getText();
            pw.println(fillerString);
            pw.close();
            txtFileChooser.setText("");
            this.txtNewFileName.setEnabled(false);
            this.lblNewFileName.setEnabled(false);
            txtFileChooser.setText("");
          
            
        }
        
    }//GEN-LAST:event_btnSaveActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(builder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(builder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(builder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(builder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
            

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new builder().setVisible(true);
            }
        });
           
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaDisplay;
    private javax.swing.JButton btnAppend;
    private javax.swing.JButton btnOpen;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSaveAs;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lblFileChooser;
    private javax.swing.JLabel lblNewFileName;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextField txtFileChooser;
    private javax.swing.JTextField txtNewFileName;
    // End of variables declaration//GEN-END:variables
}
