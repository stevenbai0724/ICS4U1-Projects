/*
 Steven Bai
Unit 2 Activity 4 - Assignment - Student Grades
Due date: Dec 15 2020 22:30
ICS4U1-D3
Assignment: https://tdsb.elearningontario.ca/content/enforced/18472876-BL_CS_ICS4U1-D3_936990_2021Sem2/ICS4U%20(Java)PU02/ICS4U%20(Java)PU02A04/assignment.html?d2lSessionVal=L1itfL9QzaM3RQyeFPPW72mGA&ou=18472876&d2l_body_type=3

This program will implement 2D Arrays to keep track of student names, grades and their averages
The program will store up to 15 names and 4 mark entries
The requirements are the following:
-input/output screens
-use 2D array to store data
-add, list, student average, course average buttons


 */


public class studentGrades extends javax.swing.JFrame {
    
    //The 2D array to stores names and grades. 
    //15 rows of names, 1 coloumn for each name and 4 coloumns for each test mark
    //Last column will hold the average of the student
    String [][] arr = new String[15][6];
    int count = 0;//keeps track of how many students there are
    

    public studentGrades() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblInput4 = new javax.swing.JLabel();
        lblTitle = new javax.swing.JLabel();
        lblInput = new javax.swing.JLabel();
        txtInput = new javax.swing.JTextField();
        txtTest1 = new javax.swing.JTextField();
        txtTest2 = new javax.swing.JTextField();
        txtTest3 = new javax.swing.JTextField();
        txtTest4 = new javax.swing.JTextField();
        lblInput1 = new javax.swing.JLabel();
        lblInput2 = new javax.swing.JLabel();
        lblInput3 = new javax.swing.JLabel();
        lblInput5 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        btnCourseAverage = new javax.swing.JButton();
        btnList = new javax.swing.JButton();
        btnStudentAverage = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaOutput = new javax.swing.JTextArea();

        lblInput4.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblInput4.setText("Full Name:");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
        lblTitle.setText("Student Grades");

        lblInput.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblInput.setText("Full Name:");

        txtInput.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtInputActionPerformed(evt);
            }
        });

        txtTest1.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtTest1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTest1ActionPerformed(evt);
            }
        });

        txtTest2.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtTest2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTest2ActionPerformed(evt);
            }
        });

        txtTest3.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtTest3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTest3ActionPerformed(evt);
            }
        });

        txtTest4.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtTest4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTest4ActionPerformed(evt);
            }
        });

        lblInput1.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblInput1.setText("Test 1:");

        lblInput2.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblInput2.setText("Test 3:");

        lblInput3.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblInput3.setText("Test 4:");

        lblInput5.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblInput5.setText("Test 2:");

        btnAdd.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnCourseAverage.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnCourseAverage.setText("Course Average");
        btnCourseAverage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCourseAverageActionPerformed(evt);
            }
        });

        btnList.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnList.setText("List");
        btnList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListActionPerformed(evt);
            }
        });

        btnStudentAverage.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnStudentAverage.setText("Student Average");
        btnStudentAverage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStudentAverageActionPerformed(evt);
            }
        });

        btnExit.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        areaOutput.setColumns(20);
        areaOutput.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        areaOutput.setRows(5);
        jScrollPane1.setViewportView(areaOutput);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblInput)
                            .addComponent(lblInput1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblInput5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblInput2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblInput3, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtTest4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                                        .addComponent(txtTest1, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtTest2, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txtTest3, javax.swing.GroupLayout.Alignment.LEADING))
                                    .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(33, 33, 33)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnList, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnAdd)
                                    .addComponent(btnStudentAverage)
                                    .addComponent(btnCourseAverage)
                                    .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(lblTitle)))
                .addContainerGap(110, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblInput)
                    .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTest1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblInput1)
                    .addComponent(btnList))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTest2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblInput5)
                    .addComponent(btnStudentAverage))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTest3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblInput2)
                    .addComponent(btnCourseAverage))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblInput3)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtTest4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnExit)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtInputActionPerformed

    private void txtTest1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTest1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTest1ActionPerformed

    private void txtTest2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTest2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTest2ActionPerformed

    private void txtTest3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTest3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTest3ActionPerformed

    private void txtTest4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTest4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTest4ActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        // Add button: Adds the name and marks on screen 
        
        String temp = txtInput.getText();//name
        //Convert test marks to integers, to calculate average
        int t1 = Integer.parseInt(txtTest1.getText());
        int t2 = Integer.parseInt(txtTest2.getText());
        int t3 = Integer.parseInt(txtTest3.getText());
        int t4 = Integer.parseInt(txtTest4.getText());
        arr[count][0] = temp; //update name in the array
        //update 4 test marks 
        arr[count][1] = Integer.toString(t1);
        arr[count][2] = Integer.toString(t2);
        arr[count][3] = Integer.toString(t3);
        arr[count][4] = Integer.toString(t4);
        //calculate average fo the 4 tests
        arr[count][5] = " Avg: " + Double.toString((t1+t2+t3+t4)/4.0);
        
        count++; //increment the total number of students
         
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListActionPerformed
        // List button: outputs all the names stored 
        
        areaOutput.setText("");//clear output field first
        //loop up until the last student, indicated by counter
        for(int i=0;i<count;i++){
            String temp = "";//output
            //loop through the columns of each row
            for(int j=0;j<=5;j++){
                temp+=arr[i][j] + " ";//concating value from array to output
            }
            temp +="\n"; //newline for the next set of output
            areaOutput.append(temp);
        }
        
    }//GEN-LAST:event_btnListActionPerformed

    private void btnStudentAverageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStudentAverageActionPerformed
        //Student average: Outputs information of chosen student
        
        
        String temp = txtInput.getText();//name of student
        areaOutput.setText("");//clear output area first
        //loop through the 1st column of each row to search for student
        for(int i=0;i<count;i++){
            if(arr[i][0].equals(temp)){ //execute if we found the match
                String ans = "";//answer
                for(int j = 0;j<=5;j++){
                    ans += arr[i][j] + " ";//concat each value in row of student
                }
                areaOutput.setText(ans);
                break; //end loop
            }
        }
    }//GEN-LAST:event_btnStudentAverageActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // Exit 
        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnCourseAverageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCourseAverageActionPerformed
        //Course average: average of each of the tests, number of students
        
        areaOutput.setText("");//get rid of existing text on screen
        areaOutput.append("Number of students: "+ count+"\n");
        double test1 =0;
        double test2 = 0;
        double test3 = 0;
        double test4 = 0;
        for(int i =0;i<count;i++){//loop through all the enrolled students
            //add the scores of the ith student
            test1 += Double.parseDouble(arr[i][1]); 
            test2 += Double.parseDouble(arr[i][2]); 
            test3 += Double.parseDouble(arr[i][3]); 
            test4 += Double.parseDouble(arr[i][4]); 
        }
        //simple math to find average, dividing total by num. students
        areaOutput.append("Test 1 Average: "+ test1/count+"\n");
        areaOutput.append("Test 2 Average: "+ test2/count+"\n");
        areaOutput.append("Test 3 Average: "+ test3/count+"\n");
        areaOutput.append("Test 4 Average: "+ test4/count+"\n");
        
        
    }//GEN-LAST:event_btnCourseAverageActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(studentGrades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(studentGrades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(studentGrades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(studentGrades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new studentGrades().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaOutput;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnCourseAverage;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnList;
    private javax.swing.JButton btnStudentAverage;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblInput;
    private javax.swing.JLabel lblInput1;
    private javax.swing.JLabel lblInput2;
    private javax.swing.JLabel lblInput3;
    private javax.swing.JLabel lblInput4;
    private javax.swing.JLabel lblInput5;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextField txtInput;
    private javax.swing.JTextField txtTest1;
    private javax.swing.JTextField txtTest2;
    private javax.swing.JTextField txtTest3;
    private javax.swing.JTextField txtTest4;
    // End of variables declaration//GEN-END:variables
}
