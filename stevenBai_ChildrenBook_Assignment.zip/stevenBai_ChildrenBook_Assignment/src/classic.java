/*
Book object
2 fields: int index, string name
 */

public class classic {
        int index;
        String name;
        
        classic(int i, String n){
            index = i;
            name = n;
            
        }
}
