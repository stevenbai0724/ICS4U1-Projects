/*
Steven Bai
Unit 3 Activity 3 - Assignment - Children's books
Due date: Jan 22 2021 23:30
ICS4U1-D3

This program will use file readers and searching algorithms to acquire any string in a text file, given its index
The linear search method iterates through all N items and runs in O(N) time 
The binary search method will use a left and right pointer and iterate through the indicies in O(log_2 N) time

The linear search is guaranteed to work, whether the data is sorted or not
Binary search we must assume that the data is given in non-decreasing order of indicies
The indicies do not have to be consecutive in both algorithms

An example of the data in the text file would be as follows:

1
Cat in the Hat
2
Charlotte's Web
5
Winnie-the-Pooh
8
The Bearstain Bears
14
Alice in Wonderland

 */
//ArrayList and file reader imports
import java.util.*;
import java.io.*;
public class books extends javax.swing.JFrame {

    BufferedReader fileIn;
    ArrayList<classic>list = new ArrayList(); //saves the books as an object
    
    public books() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        lblTitle1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        txtFile = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnImport = new javax.swing.JButton();
        btnSearch = new javax.swing.JButton();
        txtOutput1 = new javax.swing.JTextField();
        txtOutput2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle1.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
        lblTitle1.setText("Children's Classics");

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel1.setText("Linear Search");

        txtSearch.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N

        txtFile.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtFile.setText("C:\\Users\\steve\\Desktop\\test.txt");
        txtFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFileActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel3.setText("Enter the file location:");

        btnImport.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        btnImport.setText("Import");
        btnImport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportActionPerformed(evt);
            }
        });

        btnSearch.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        btnSearch.setText("Search");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        txtOutput1.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N

        txtOutput2.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel4.setText("Enter the index number of the book:");

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        jLabel5.setText("Binary Search");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtFile, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnImport))
                    .addComponent(jLabel3)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(lblTitle1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txtOutput2, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSearch)
                            .addComponent(txtOutput1, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle1)
                .addGap(34, 34, 34)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnImport))
                .addGap(27, 27, 27)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearch)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtOutput1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtOutput2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(54, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnImportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportActionPerformed
        // Gets file location and opens text
        // Opens text file from input
        String filename = txtFile.getText();
        Boolean saveInt = true; //this will decide whether the file reader will save the current file element as an integer or string, which will alternate as T/F
        String word = "";
        
        //temp variables for storing in list
        String curTitle = "";
        int curIndex = 0;
        

        try{
            //open the direct file location , e.g C:\\Users\\Mike\\Desktop\\test.txt
            fileIn = new BufferedReader(new FileReader(filename));
        }
        catch(Exception e){
            System.out.println("not found");
        }
        try{ //read each line of file and add it to the LoadedArray
            while((word = fileIn.readLine()) != null) {
                if(saveInt){
                    curIndex = Integer.parseInt(word); //save as index
                    saveInt = !saveInt; //toggle 
                }
                else{
                    curTitle = word; //save as title this time
                    classic book  = new classic(curIndex, curTitle); //create new object 
                    list.add(book);
                    saveInt = !saveInt; //toggle
                }
             
          }
        }
        catch (IOException ex){
            System.out.println("File reading error");
        }
        
        
    }//GEN-LAST:event_btnImportActionPerformed

    private void txtFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFileActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFileActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        //Excecute the search
        int lookFor = Integer.parseInt(txtSearch.getText());
        linearSearch(lookFor);
        binarySearch(lookFor);
    }//GEN-LAST:event_btnSearchActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new books().setVisible(true);
            }
        });
    }
    public void linearSearch(int n){
        //iterate through all elements
        for(int i=0;i<list.size();i++){
            if(list.get(i).index ==n){//this is if we found the corresponding index, n
                txtOutput1.setText(list.get(i).name); //set text to title 
                return ; //end search
            }
        }
        //If not found, display in box
        txtOutput1.setText("Not found");
        return;
    }
    public void binarySearch(int n){
        //left and right pointers used for this process
        int l = 0;
        int r = list.size()-1; 
        //terminate when l and r have met, or if we are lucky we will find it before
        while(l<r){
            int m = (l+r)/2; //middle
            
            //we found the index, so return 
            if(list.get(m).index==n){
                txtOutput2.setText(list.get(m).name);
                return;
            }
            //notice that l moves up by one after m, but r stays at m. This will cover the case if our index is at point r, otherwise an inf loop is created
            if(list.get(m).index<n)l = m+1; 
            if(list.get(m).index>n)r = m; 
            
            
        }
        //The case that r and l and met at exactly the correct index
        if(list.get(l).index==n){
            txtOutput2.setText(list.get(l).name);
            return;
                
        }
        //otherwise, not found
        txtOutput2.setText("Not found");
        return;
        
        
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnImport;
    private javax.swing.JButton btnSearch;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel lblTitle1;
    private javax.swing.JTextField txtFile;
    private javax.swing.JTextField txtOutput1;
    private javax.swing.JTextField txtOutput2;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
