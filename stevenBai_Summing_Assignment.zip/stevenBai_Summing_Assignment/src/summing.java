/*
 Steven Bai
Unit 2 Activity 2 - Assignment - Summing array elements 
Due date: Dec 8 2020 22:45
ICS4U1-D3

This program is an interactive menu that stores integers from the user's input and does the following operations:
-Adding and removing specific elements 
-Listing and summing all elements
-Listing and summing all even/odd elements
-Listing a sorted version of the entered numbers

instead of using an iterator, I chose to loop through the List and use the list.get() method for my operations
instead of having a list button, the program will automatically list after the operations (remove, add, etc) are used. 
        -this will be more convenient for the user
        -saves typing
        -listElements() outputs everything, listSpecifc() will output only even/odd elements
 */
import java.util.*;
import java.io.*;

public class summing extends javax.swing.JFrame {
   
    ArrayList<Integer>list = new ArrayList(); //global list that stores all the elements to be manipulated

    public summing() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblEnter = new javax.swing.JLabel();
        txtInput = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaOutput = new javax.swing.JTextArea();
        txtOutput = new javax.swing.JTextField();
        btnRemove = new javax.swing.JButton();
        btnSort = new javax.swing.JButton();
        btnSumOdd = new javax.swing.JButton();
        btnSumEven = new javax.swing.JButton();
        btnSumAll = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Verdana", 0, 36)); // NOI18N
        lblTitle.setText("Integer Sums");

        lblEnter.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        lblEnter.setText("Enter an integer: ");

        txtInput.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtInputActionPerformed(evt);
            }
        });

        btnAdd.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        areaOutput.setColumns(20);
        areaOutput.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        areaOutput.setRows(5);
        jScrollPane1.setViewportView(areaOutput);

        txtOutput.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        txtOutput.setText(" ");

        btnRemove.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnRemove.setText("Remove");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });

        btnSort.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSort.setText("Sort");
        btnSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSortActionPerformed(evt);
            }
        });

        btnSumOdd.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSumOdd.setText("Sum odd");
        btnSumOdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSumOddActionPerformed(evt);
            }
        });

        btnSumEven.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSumEven.setText("Sum even");
        btnSumEven.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSumEvenActionPerformed(evt);
            }
        });

        btnSumAll.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSumAll.setText("Sum all");
        btnSumAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSumAllActionPerformed(evt);
            }
        });

        btnExit.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        btnClear.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblEnter, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(31, 31, 31)
                                    .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnAdd)
                                        .addComponent(btnSumEven)
                                        .addComponent(btnSumOdd)
                                        .addComponent(btnSumAll)
                                        .addComponent(btnSort)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnClear)
                            .addComponent(btnExit)
                            .addComponent(btnRemove))
                        .addContainerGap(37, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEnter)
                    .addComponent(txtInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdd)
                    .addComponent(btnRemove))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSort)
                            .addComponent(btnClear))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSumAll)
                            .addComponent(btnExit))
                        .addGap(18, 18, 18)
                        .addComponent(btnSumOdd)
                        .addGap(18, 18, 18)
                        .addComponent(btnSumEven)))
                .addGap(36, 36, 36)
                .addComponent(txtOutput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 47, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        //Add button: taking user input and storing in the global ArrayList, then displaying it
        
        int num = Integer.parseInt(txtInput.getText()); //converting string input to integer
        
        list.add(num);  
        
        listElements(); //output the updated list
       
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        //Remove button: taking user input and removing the element from the list (if it exists)
        
        int num = Integer.parseInt(txtInput.getText()); //converting string input to integer
        
        //looping through the list to find the element to remove. If not found, nothing will happen
        for(int i=0;i<list.size();i++){
              if(list.get(i)==num){ //becomes true if we have found the element in the list
                  list.remove(i); //remove the index that we want, since .remove() removes the INDEX
                  break; //stop the loop, to prevent removing duplicates
              }
        }
        listElements();//update the list on screen
        
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void txtInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtInputActionPerformed
        //No actions
    }//GEN-LAST:event_txtInputActionPerformed

    private void btnSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSortActionPerformed
        // Sort button: An extra add-on that sorts the list from smallest to largest
        Collections.sort(list); //a built in method that sorts ArrayLists
        listElements();//output the elements
        
    }//GEN-LAST:event_btnSortActionPerformed

    private void btnSumOddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSumOddActionPerformed
        // Sum Odd button: outputs the sum of the ODD elements
        
        int sum = 0; //stores sum
        
        //loop through all elements
        for(int i=0;i<list.size();i++){
            if(list.get(i)%2==1) sum+=list.get(i); //check if number is odd, and then add to sum
        }
        listSpecific(1);//outputs odd nums
        txtOutput.setText("The sum of all the odds elements is: " + Integer.toString(sum)); //update the text 
        
        
        
    }//GEN-LAST:event_btnSumOddActionPerformed

    private void btnSumEvenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSumEvenActionPerformed
         // Sum Even button: outputs the sum of the EVEN elements
        
        int sum = 0; //stores sum
        
        //loop through all elements
        for(int i=0;i<list.size();i++){
            if(list.get(i)%2==0) sum+=list.get(i); //check if number is even, and then add to sum
        }
        listSpecific(0); //output even nums
        txtOutput.setText("The sum of all the even elements is: " + Integer.toString(sum)); //update the text 
    }//GEN-LAST:event_btnSumEvenActionPerformed

    private void btnSumAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSumAllActionPerformed
        // Bum All button: outputs the sum of all the elements
        
        int sum = 0;//stores sum
        
        //loop through all the elements of the list
        for(int i=0;i<list.size();i++){
            sum+=list.get(i);//adding the current element of the list to the total
        }
        listElements();
        txtOutput.setText("The sum of all the elements is: " + Integer.toString(sum)); //update the text 
        
    }//GEN-LAST:event_btnSumAllActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // Exit button
        
        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // Clear button: clears the list and everything on screen
        list.clear(); 
        areaOutput.setText(""); //clears the elements on screen
        txtOutput.setText(""); //clears text field output
        txtInput.setText(""); //clears text field input
    }//GEN-LAST:event_btnClearActionPerformed

    private void listElements(){
        //this method is simply used to display the elements on the screen in a procedural manner
        
        String a = ""; //stores the output
        //loop throught the elements of the list, and adding each of them to the output as a string
        for(int i =0;i<list.size();i++){
            String temp = Integer.toString(list.get(i)); //string conversion 
            a+= (temp + "\n"); //string concatenation on new line so the elements are listed out with spaces
        }
        areaOutput.setText(a); //display 
    }
    private void listSpecific(int x){ //argument will decide which parity to list, 1 for odd, 0 for even
        //this method is used to list only even/odd elements when user clicks "sum odd" or "sum even"
        
        String a = "";//output
        for(int i=0;i<list.size();i++){
            if(list.get(i)%2==x){ //check to see if element is the desired parity
                String temp = Integer.toString(list.get(i));//string conversion
                a += (temp+ "\n");//concat on new line
            }
        }
        areaOutput.setText(a);//display      
    }
    
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(summing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(summing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(summing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(summing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new summing().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaOutput;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnSort;
    private javax.swing.JButton btnSumAll;
    private javax.swing.JButton btnSumEven;
    private javax.swing.JButton btnSumOdd;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblEnter;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextField txtInput;
    private javax.swing.JTextField txtOutput;
    // End of variables declaration//GEN-END:variables
}
