/*
Steven Bai
Unit 3 Activity 4 - Sorting efficiencies
Due date: Jan 29 2021 23:30
ICS4U1-D3

This program will generate random numbers and sort them with 4 of the following algorithms:
-bubble
-selection
-insertion
-quicksort

The functionality of the algorithms are briefly explained here:
bubble: swap 2 adjacent elements that are out of place until array is sorted
selection: goes through all elements of the array and finds the min/max, adding it to the beginning each time
insertion: orders the first 2 elements. Starting from the 3rd,  insert it to the correct position of the previous elements 
quicksort: a recursive sort that partitions the array from a pivot, and recursively sorts both sides of the pivot

The user can choose to sort in ascending or descending order.

For each algorithm, the execution time, number of loops and number of swaps & comparisons is displayed after being calculated in its respecitve method



 */
public class sorting extends javax.swing.JFrame {
    
    //Counters for time (ms), num. loops, num. swaps, num comparison
    //Must be global!!
    long bubbleTime =0 , bubbleLoop=0, bubbleSwap = 0, bubbleComp = 0;
    long selectionTime =0, selectionLoop=0, selectionSwap =0, selectionComp = 0;
    long insertionTime = 0, insertionLoop =0, insertionSwap = 0, insertionComp = 0;
    long quicksortTime = 0, quicksortLoop = 0,quicksortSwap = 0, quicksortComp = 0;

    public sorting() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        lblTitle1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btn10 = new javax.swing.JRadioButton();
        btn1000 = new javax.swing.JRadioButton();
        btn5000 = new javax.swing.JRadioButton();
        btn100 = new javax.swing.JRadioButton();
        btnSort = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnAsc = new javax.swing.JRadioButton();
        btnDec = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaUnsort = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        areaSort = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        areaOutput = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle1.setFont(new java.awt.Font("Verdana", 0, 24)); // NOI18N
        lblTitle1.setText("Sorting Efficiencies");

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        jLabel1.setText("Amount of numbers: ");

        buttonGroup1.add(btn10);
        btn10.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btn10.setText("10");

        buttonGroup1.add(btn1000);
        btn1000.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btn1000.setText("1000");

        buttonGroup1.add(btn5000);
        btn5000.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btn5000.setText("5000");

        buttonGroup1.add(btn100);
        btn100.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btn100.setText("100");

        btnSort.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnSort.setText("Sort ");
        btnSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSortActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        jLabel2.setText("Order: ");

        buttonGroup2.add(btnAsc);
        btnAsc.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnAsc.setText("Ascending");

        buttonGroup2.add(btnDec);
        btnDec.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnDec.setText("Descending");

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        jLabel3.setText("Unsorted");

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        jLabel4.setText("Sorted");

        areaUnsort.setColumns(20);
        areaUnsort.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        areaUnsort.setRows(5);
        jScrollPane2.setViewportView(areaUnsort);

        areaSort.setColumns(20);
        areaSort.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        areaSort.setRows(5);
        jScrollPane3.setViewportView(areaSort);

        areaOutput.setColumns(20);
        areaOutput.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        areaOutput.setRows(5);
        jScrollPane4.setViewportView(areaOutput);

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        jLabel5.setText("Sort Results:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(312, 312, 312)
                .addComponent(lblTitle1)
                .addContainerGap(334, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnDec)
                                    .addComponent(btnAsc)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(btnSort, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel1))
                                        .addGap(18, 18, 18)
                                        .addComponent(btn10))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(27, 27, 27)
                                        .addComponent(jLabel3)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btn100)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btn1000)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btn5000))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addComponent(jLabel5))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle1)
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(btn10)
                    .addComponent(btn100)
                    .addComponent(btn1000)
                    .addComponent(btn5000)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSort, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(btnAsc))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnDec)
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3)
                            .addComponent(jScrollPane2)))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 469, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSortActionPerformed
        //Sort button
       //get size of array, as well as the number of random numbers to generate
        int n = 0;
        if(btn10.isSelected())n=10;
        else if(btn100.isSelected())n=100;
        else if(btn1000.isSelected())n=1000;
        else n = 5000;
       
        //we need seperate arrays for each algorithm.
        //If we use the same array name, the first one will sort the array and the 2nd-4th method calls will receive an array that's already sorted 
        //which defeats the purpose, and the counters will all be zero
        int[] arr1 = new int[n]; 
        int[] arr2 = new int[n];
        int[] arr3 = new int[n];
        int[] arr4 = new int[n];
        
        int[] newArr = new int[1]; //the new sorted array that will be obtained from the sorting methods. Set to arbitrary length
        
        //reset text and counters for new output
        areaUnsort.setText("");
        areaSort.setText("");
        areaOutput.setText("");
        reset();
        
        for(int i=0;i<n;i++){
            //populating arrs with random numbers, [-10000,10000]
            int x = (int)(Math.random()*(20001))-10000; // range -10000 ->10000
            arr1[i] = x;
            arr2[i] = x;
            arr3[i] = x;
            arr4[i] = x;
            areaUnsort.append(String.valueOf(x) + '\n'); //add unsorted element to textarea
        }
        //determine order and algorithm to use
        Boolean ascend = btnAsc.isSelected(); //decides which order to sort

        //all sort methods will take arr, size and order. They will return the sorted array
        //Theoretically, these should all return the same value
        //Times and counts will be calculated in the sorting methods
        
        newArr = bubble(arr1,n, ascend);
        selection(arr2, n, ascend);
        insertion(arr3, n, ascend);

        //since quicksort is recursive, we will calculate execution time by (time return) - (time called)
        long start = System.currentTimeMillis();;
        quicksort(arr4, 0, n-1, ascend);
        long end = System.currentTimeMillis();
        
        quicksortTime = end-start;
        
        //append the sorted array to the new text area
        for(int i=0;i<n;i++){
            areaSort.append(String.valueOf(newArr[i]) + '\n');
        }
        //put all the information together and append as a string
        String word = "";
        word += "Bubble sort:\n";
        word += "Time: " + String.valueOf(bubbleTime) +" ms " + '\n';
        word += "Loops: " + String.valueOf(bubbleLoop) + '\n';
        word += "Swaps: " + String.valueOf(bubbleSwap) +'\n';
        word += "Comparisons :" + String.valueOf(bubbleComp) + '\n' + '\n';
        
        word += "Selection sort:\n";
        word += "Time: " + String.valueOf(selectionTime) +" ms " + '\n';
        word += "Loops: " + String.valueOf(selectionLoop) + '\n';
        word += "Swaps: " + String.valueOf(selectionSwap) +'\n';
        word += "Comparisons :" + String.valueOf(selectionComp) + '\n' +'\n';
        
        word += "Insertion sort:\n";
        word += "Time: " + String.valueOf(insertionTime) +" ms " + '\n';
        word += "Loops: " + String.valueOf(insertionLoop) + '\n';
        word += "Swaps: " + String.valueOf(insertionSwap) +'\n';
        word += "Comparisons :" + String.valueOf(insertionComp) + '\n' + '\n';
        
        word += "Quicksort:\n";
        word += "Time: " + String.valueOf(quicksortTime) +" ms " + '\n';
        word += "Loops: " + String.valueOf(quicksortLoop) + '\n';
        word += "Swaps: " + String.valueOf(quicksortSwap) +'\n';
        word += "Comparisons :" + String.valueOf(quicksortComp) + '\n';        
        
        areaOutput.append(word);
        
       
    }//GEN-LAST:event_btnSortActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(sorting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(sorting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(sorting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(sorting.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new sorting().setVisible(true);
            }
        });
    }
    public int[] bubble(int arr[], int n, Boolean asc){ //bubble sort, returns the sorted array
       
            long start = System.currentTimeMillis(); //start time

            while(true){
                Boolean sorted = true;
                bubbleLoop++; //count loops in the bigger loop
                for(int i=0;i<n-1;i++){
                    bubbleComp++; //count comparisons in the smaller loop
                    //the magic happens here
                    //If we want the ascending array, we swap when arr[i]>arr[i+1]
                    //If we want the descending array, we swap when arr[i]<arr[i+1]
                    if((arr[i]>arr[i+1] && asc) || (arr[i]<arr[i+1] && !asc) ){
                        sorted =false; //not sorted if we find out of place elements
                        //swap
                        int temp = arr[i];
                        arr[i] = arr[i+1];
                        arr[i+1] = temp;
                        bubbleSwap++; //increment
                        
                    }
                }
                if(sorted)break; //break if we do not find any out of place elements
            }
            long end = System.currentTimeMillis(); //end time
 
            bubbleTime = end-start; //time

        return arr; //return sorted array
    }
    public int[] selection(int []arr, int n, Boolean asc){ //selection sort, returns int[]
        
        long start = System.currentTimeMillis();
        for(int i=0;i<n-1;i++){
            selectionLoop++;
            int mn = 1000000; //needed for ascending array
            int mx = -1000000; //needed for descending array
            int indexMx = 0; //index for swap
            int indexMn = 0;
            //find max and min in the array , store the indicies for swap
            for(int j=i;j<n;j++){
                selectionComp++;
                if(arr[j]<mn){
                    mn = arr[j];
                    indexMn = j;
                }
                if(arr[j]>mx){
                    mx = arr[j];
                    indexMx = j;
                }
            }
            
            //we have found the max and min in the array, so we will use these values accordingly for a swap
            //swap beginning with max for descending, min for ascending
            if(asc){
                
                int temp = arr[i];
                arr[i] = arr[indexMn];
                arr[indexMn] = temp;
            }else{
                
                int temp = arr[i];
                arr[i] = arr[indexMx];
                arr[indexMx] = temp;
            }
            
            selectionSwap++; //selection swap makes exactly n swaps (program will still swap with itself if element is in correct spot)
            
        }
        
        long end = System.currentTimeMillis();
        selectionTime = end-start;
        
        return arr;
    }
    public int[] insertion (int []arr, int n, Boolean asc){
        //with insertion sort, we take an element i and keep swapping with i-1, i-2 .... until we find the right spot or when we reach i=0
        //we can assume that for any i>1, all elements from 1 to i-1 are sorted, we just to find where to insert element i, hence the name
        long start = System.currentTimeMillis();

        
        for(int i=1;i<n;i++){
            insertionLoop++;
            int temp = arr[i];
            int j = i-1; //index before
            
            while(j>=0){ //shift until we reach beginning of array
                //we must consider these 2 conditions, for ascending and descending respectively
                if(asc && arr[j]<temp)break;
                if(!asc && arr[j]>temp)break;
                arr[j+1] = arr[j]; //shift
                j--;
                insertionSwap++; //shift can be considered as a swap
                insertionComp++; //everytime we make a compare, we must also swap until comparison is not needed. Therefore comp = swap
           
            }
            arr[j+1] = temp; //insert arr[i] into the correct pos.
        }
        long end = System.currentTimeMillis();
       
        insertionTime = end-start;
        
        return arr;
    }
    public int[] quicksort(int[] arr, int lo, int hi, Boolean asc){
            
            int i = lo;
            int j = hi;
            int temp;
            int p =arr[(i+j)/2]; //pivot
            
            while(i<=j){
                
                if(asc){
                    //find two elements to swap for asc
                    //when finding two elements, we increment the comparisons made each time
                    while(arr[i]<p){
                        i++;
                        quicksortComp++;
                    }
                    while(arr[j]>p){
                        quicksortComp++;
                        j--;
                    }
                }
                else{//find swap, for !asc
                    while(arr[i]>p){
                        i++;
                        quicksortComp++;
                    }
                    while(arr[j]<p){
                        j--;
                        quicksortComp++;
                    }
                }
                if(i<=j){//swap into correct positions;
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                    i++;
                    j--;
                    quicksortSwap++; //swap counter
                    
                }
            }
            //Increment the loop counter, when the program calls itself recursively
            if(lo<j){//recursively sort lower subarray
                quicksortLoop++; //counter increment
                quicksort(arr, lo, j, asc);
                
            }
            if(i<hi){//recursively sort upper subarray
                quicksortLoop++; //counter increment
                quicksort(arr, i, hi, asc);
            }
            return arr;
   
    }
            
    public void reset(){
        //resets time counters
        bubbleTime =0 ;
        bubbleLoop=0; 
        bubbleSwap = 0;
        bubbleComp = 0;
        selectionTime =0;
        selectionLoop=0; 
        selectionSwap =0;
        selectionComp = 0;
        insertionTime = 0; 
        insertionLoop =0; 
        insertionSwap = 0;
        insertionComp = 0;
        quicksortTime = 0;
        quicksortLoop = 0;
        quicksortSwap = 0;
        quicksortComp = 0;

    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaOutput;
    private javax.swing.JTextArea areaSort;
    private javax.swing.JTextArea areaUnsort;
    private javax.swing.JRadioButton btn10;
    private javax.swing.JRadioButton btn100;
    private javax.swing.JRadioButton btn1000;
    private javax.swing.JRadioButton btn5000;
    private javax.swing.JRadioButton btnAsc;
    private javax.swing.JRadioButton btnDec;
    private javax.swing.JButton btnSort;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lblTitle1;
    // End of variables declaration//GEN-END:variables
}
