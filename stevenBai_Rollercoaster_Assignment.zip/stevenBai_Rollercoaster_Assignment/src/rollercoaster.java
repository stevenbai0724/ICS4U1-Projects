/*
 Steven Bai
Activity 4 - Assignment - Rollercoaster
Due date: Dec 2, 2020 11:59 pm
ICS4U1-D3

This program will determine whether or not the user is eligible to ride a rollercoaster based on the input:
Height   (122cm <= h<= 188cm)
Back trouble (N)
Heart trouble (N)

2 of the choices have been implemented with toggle buttons
 */
public class rollercoaster extends javax.swing.JFrame {

    //booleans to keep track of user input for back and/or heart problems
    static boolean tog1 = false;
    static boolean tog2 = false; 
    
    public rollercoaster() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtTitle = new javax.swing.JLabel();
        txtHeight = new javax.swing.JLabel();
        txtBack = new javax.swing.JLabel();
        txtHeart = new javax.swing.JLabel();
        btnCalculate = new javax.swing.JButton();
        fieldHeight = new javax.swing.JTextField();
        fieldOutput = new javax.swing.JTextField();
        tgl1 = new javax.swing.JToggleButton();
        tgl2 = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtTitle.setFont(new java.awt.Font("Verdana", 0, 36)); // NOI18N
        txtTitle.setText("Rollercoaster Ride");

        txtHeight.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtHeight.setText("Height (in cm)");

        txtBack.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtBack.setText("Back trouble (Y/N)?");

        txtHeart.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtHeart.setText("Heart trouble (Y/N)?");

        btnCalculate.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        btnCalculate.setText("Calculate");
        btnCalculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalculateActionPerformed(evt);
            }
        });

        fieldHeight.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        fieldHeight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldHeightActionPerformed(evt);
            }
        });

        fieldOutput.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        fieldOutput.setText(" ");
        fieldOutput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldOutputActionPerformed(evt);
            }
        });

        tgl1.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        tgl1.setText("No");
        tgl1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                tgl1ItemStateChanged(evt);
            }
        });
        tgl1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tgl1ActionPerformed(evt);
            }
        });

        tgl2.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        tgl2.setText("No");
        tgl2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tgl2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtHeight, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(fieldHeight, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(fieldOutput)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnCalculate)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtHeart)
                            .addComponent(txtBack))
                        .addGap(178, 178, 178)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tgl1, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                            .addComponent(tgl2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(txtTitle)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtHeight, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fieldHeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBack, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tgl1))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtHeart, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tgl2))
                .addGap(37, 37, 37)
                .addComponent(btnCalculate)
                .addGap(18, 18, 18)
                .addComponent(fieldOutput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(86, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCalculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalculateActionPerformed
            
          //taking the input
          int height = Integer.parseInt(fieldHeight.getText());
       
          //tog1 and tog2 are declared at the top. They are modified when the user interacts with the toggle buttons
          if(height>=122 && height<=188 && !tog1 && !tog2) fieldOutput.setText("You can ride the rollercoaster. Enjoy!");
          else fieldOutput.setText("Sorry, it is not safe for you to ride.");
        
        
    }//GEN-LAST:event_btnCalculateActionPerformed

    private void fieldHeightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldHeightActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldHeightActionPerformed

    private void fieldOutputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldOutputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fieldOutputActionPerformed

    private void tgl1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tgl1ActionPerformed
        
        tog1 = !tog1; //boolean tog1 will change everyone time button is clicked
           
        //text will update accordingly
        if(tog1) tgl1.setText("Yes");
        else tgl1.setText("No");
    }//GEN-LAST:event_tgl1ActionPerformed

    private void tgl1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_tgl1ItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_tgl1ItemStateChanged

    private void tgl2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tgl2ActionPerformed
          
          //same function and purpose as toggle button 1
          tog2 = !tog2;
          
          if(tog2) tgl2.setText("Yes");
          else tgl2.setText("No");
    }//GEN-LAST:event_tgl2ActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(rollercoaster.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(rollercoaster.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(rollercoaster.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(rollercoaster.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new rollercoaster().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalculate;
    private javax.swing.JTextField fieldHeight;
    private javax.swing.JTextField fieldOutput;
    private javax.swing.JToggleButton tgl1;
    private javax.swing.JToggleButton tgl2;
    private javax.swing.JLabel txtBack;
    private javax.swing.JLabel txtHeart;
    private javax.swing.JLabel txtHeight;
    private javax.swing.JLabel txtTitle;
    // End of variables declaration//GEN-END:variables
}
