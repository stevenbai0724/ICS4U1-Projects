/*
Passenger class for creating the object
Each passenger will have 5 fields:
    -Name
    -Points for weeks 1-4
 */


public class passenger {
        String name, week1 ,week2, week3, week4;
        
        passenger(String n, String w1, String w2, String w3, String w4){
            name = n;
            week1 = w1;
            week2 = w2;
            week3 = w3;
            week4 = w4;
        }
        
}
