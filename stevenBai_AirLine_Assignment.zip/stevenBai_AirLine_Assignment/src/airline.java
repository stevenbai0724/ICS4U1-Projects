/*
Steven Bai
Unit 2 Activity 7 - Assignment - Airline points
Due date: Jan 15 2021 23:30
ICS4U1-D3

This program will use an ArrayList of objects to store information about several passenger's airline points
These are the following operations:
Add:
    -Appends full name and weeks 1-4 to an object arraylist
    -Saves these 5 fields in a custom file, location is to be entered by user
    -The Builder program can be used to quickly retrieve/edit the file!
List:
    -Outputs all the names and their respective points
Total points:
    -Ouputs total points of a given passenger
    -Calculates passenger's eligiblilty for bonus points (+1000 if >=5000) by using Integer.parseInt()
Reset:
    -Erases all data (excluding the save file)


 */

//Util is needed for ArrayLists, io is needed for bufferedwriter, filewriter and printwriter for appending information to a file
import java.util.*;
import java.io.*;
public class airline extends javax.swing.JFrame {
    
    //ArrayList of objects will store the information, as required
    ArrayList<passenger>list = new ArrayList();
    
    public airline() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtName5 = new javax.swing.JTextField();
        btnPlane1 = new javax.swing.JButton();
        btnPlane2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        lblWeek4 = new javax.swing.JLabel();
        lblWeek3 = new javax.swing.JLabel();
        lblSave = new javax.swing.JLabel();
        lblWeek1 = new javax.swing.JLabel();
        lblWeek2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaOutput = new javax.swing.JTextArea();
        txtName = new javax.swing.JTextField();
        txtWeek1 = new javax.swing.JTextField();
        txtWeek4 = new javax.swing.JTextField();
        txtWeek2 = new javax.swing.JTextField();
        txtWeek3 = new javax.swing.JTextField();
        txtSave = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        btnList = new javax.swing.JButton();
        btnPoints = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();

        txtName5.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtName5.setText("  ");
        txtName5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtName5ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnPlane1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/plane.jpg"))); // NOI18N

        btnPlane2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/plane.jpg"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 48)); // NOI18N
        jLabel1.setText("Airline points");

        lblName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblName.setText("Full name: ");

        lblWeek4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblWeek4.setText("Week 4:");

        lblWeek3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblWeek3.setText("Week 3:");

        lblSave.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblSave.setText("Save file location");

        lblWeek1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblWeek1.setText("Week 1: ");

        lblWeek2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblWeek2.setText("Week 2:");

        areaOutput.setColumns(20);
        areaOutput.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        areaOutput.setRows(5);
        jScrollPane1.setViewportView(areaOutput);

        txtName.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });

        txtWeek1.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtWeek1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWeek1ActionPerformed(evt);
            }
        });

        txtWeek4.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtWeek4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWeek4ActionPerformed(evt);
            }
        });

        txtWeek2.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtWeek2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWeek2ActionPerformed(evt);
            }
        });

        txtWeek3.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtWeek3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWeek3ActionPerformed(evt);
            }
        });

        txtSave.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        txtSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSaveActionPerformed(evt);
            }
        });

        btnAdd.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnList.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        btnList.setText("List");
        btnList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListActionPerformed(evt);
            }
        });

        btnPoints.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        btnPoints.setText("Total Points");
        btnPoints.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPointsActionPerformed(evt);
            }
        });

        btnReset.setFont(new java.awt.Font("Verdana", 0, 18)); // NOI18N
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(btnPlane1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(btnPlane2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 611, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblSave)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtSave))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblWeek4)
                                    .addComponent(lblWeek3)
                                    .addComponent(lblWeek2))
                                .addGap(39, 39, 39)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtWeek2, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtWeek3, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtWeek4, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblName)
                                    .addComponent(lblWeek1))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(16, 16, 16)
                                        .addComponent(txtWeek1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnPoints)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(btnList, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnAdd, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(btnReset))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnPlane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPlane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel1)))
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdd))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblWeek1)
                    .addComponent(txtWeek1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnList))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtWeek2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblWeek2)
                    .addComponent(btnReset))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnPoints)
                        .addGap(12, 12, 12))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtWeek3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblWeek3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblWeek4)
                    .addComponent(txtWeek4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSave)
                    .addComponent(txtSave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameActionPerformed

    private void txtWeek1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWeek1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWeek1ActionPerformed

    private void txtWeek4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWeek4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWeek4ActionPerformed

    private void txtWeek2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWeek2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWeek2ActionPerformed

    private void txtWeek3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWeek3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWeek3ActionPerformed

    private void txtName5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtName5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtName5ActionPerformed

    private void txtSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSaveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSaveActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        // Add button: Takes string values from the 5 fields and creates an object to append to list
        // Also appends the 5 fields as a space seperated string to a file of the user's choice (location should be entered, otherwise nothing happens)
        String n, w1,w2,w3,w4;
        n = txtName.getText();
        w1 = txtWeek1.getText();
        w2 = txtWeek2.getText();
        w3 = txtWeek3.getText();
        w4 = txtWeek4.getText();
        String word = n+ " "+w1+" "+w2+" "+w3+" "+w4; //string to be appended to a file
        passenger p = new passenger(n,w1,w2,w3,w4);//new object with fields
        list.add(p);//add object to list
        
        //only append to file if user enters a location. Otherwise, skip this process
        if(!txtSave.getText().equals("")){
            String filename = txtSave.getText(); //get location
            //with a try catch stucture, the Filewriter, Buffered Writer and Printwriter are used to append the text (on screen) to a file
            try(FileWriter fw = new FileWriter(filename, true); 
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
            {
            out.println(word); //print text into file, or "appending"

            } catch (IOException e) {
            }
            
        }

        //clear the fields for new data to be entered
        txtName.setText("");
        txtWeek1.setText("");
        txtWeek2.setText("");
        txtWeek3.setText("");
        txtWeek4.setText("");
        
        
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListActionPerformed
        //List: Shows all contents of list 
        
        areaOutput.setText(""); //first, clear the existing text
        //iterate through all objects in list
        for(int i=0;i<list.size();i++){
            
            //concat and append all 5 fields into a string, and append it to the box with a newline
            String temp = "";
            temp+=list.get(i).name + " ";
            temp+=list.get(i).week1+" ";
            temp+=list.get(i).week2+" ";
            temp+=list.get(i).week3+" ";
            temp+=list.get(i).week4+"\n";
            
            areaOutput.append(temp);
        }
        
    }//GEN-LAST:event_btnListActionPerformed

    private void btnPointsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPointsActionPerformed
        // Displays points for a given passenger, and calculates eligibility for bonus
        // Linear search for object that corresponds to inputed name, and add the points for the respective passenger
        String search = txtName.getText();
        //iterate and search for name
        for(int i=0;i<list.size();i++){
            
            if(list.get(i).name.equals(search)){
                //add up points by parseInt 
                int points = 0;
                points+= Integer.parseInt(list.get(i).week1);
                points+= Integer.parseInt(list.get(i).week2);
                points+= Integer.parseInt(list.get(i).week3);
                points+= Integer.parseInt(list.get(i).week4);
                
                
                areaOutput.setText(""); //clear text first
                String temp = "Total for "+ list.get(i).name + ":\n"; //i.e "Total for Homer Simpson: "
                temp += "Points: " + String.valueOf(points) +"    Bonus: "; //i.e Points: 5000    Bonus: 
                
                if(points>=5000)temp+="1000"; //add 1000 if points are >=5000
                else temp+="0"; //add 0 otherwise
                
                areaOutput.setText(temp); //update text
                break; //stop the linear search to save time
            }   
        }
    }//GEN-LAST:event_btnPointsActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        // Reset everything
        areaOutput.setText("");
        txtName.setText("");
        txtWeek1.setText("");
        txtWeek2.setText("");
        txtWeek3.setText("");
        txtWeek4.setText("");
        txtSave.setText("");
        list.clear();
        
    }//GEN-LAST:event_btnResetActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(airline.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(airline.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(airline.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(airline.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new airline().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaOutput;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnList;
    private javax.swing.JButton btnPlane1;
    private javax.swing.JButton btnPlane2;
    private javax.swing.JButton btnPoints;
    private javax.swing.JButton btnReset;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblSave;
    private javax.swing.JLabel lblWeek1;
    private javax.swing.JLabel lblWeek2;
    private javax.swing.JLabel lblWeek3;
    private javax.swing.JLabel lblWeek4;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtName5;
    private javax.swing.JTextField txtSave;
    private javax.swing.JTextField txtWeek1;
    private javax.swing.JTextField txtWeek2;
    private javax.swing.JTextField txtWeek3;
    private javax.swing.JTextField txtWeek4;
    // End of variables declaration//GEN-END:variables
}
